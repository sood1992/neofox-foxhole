<?php
// dashboard.php - MODERN FOXHOLE Dashboard (Instadash Inspired)
require_once 'config-2.php';
require_once 'api.php';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $api = new DashboardAPI();
    
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_employee':
                $result = $api->addEmployee($_POST['name'], $_POST['email'], $_POST['role'], $_POST['type']);
                $message = $result ? "✅ Employee added successfully!" : "❌ Error adding employee.";
                break;
            case 'update_status':
                $result = $api->updateEmployeeStatus($_POST['employee_id'], $_POST['status']);
                $message = $result ? "✅ Status updated!" : "❌ Error updating status.";
                break;
            case 'add_project':
                $result = $api->addProject($_POST['name'], $_POST['description'], $_POST['client'], $_POST['priority']);
                $message = $result ? "✅ Project added successfully!" : "❌ Error adding project.";
                break;
        }
    }
}

// Get real data
$api = new DashboardAPI();
try {
    $employees_data = $api->getEmployees();
    $projects_data = $api->getProjects();
    $activities_data = $api->getRecentActivity();
    $stats = $api->getDashboardStats();
} catch (Exception $e) {
    $employees_data = [];
    $projects_data = [];
    $activities_data = [];
    $stats = ['total_employees' => 0, 'active_employees' => 0, 'total_projects' => 0, 'completed_tasks' => 0, 'avg_productivity' => 0];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foxhole - Modern ADHD-Friendly CEO Dashboard</title>
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            /* Modern Color Palette */
            --primary: #4F46E5;
            --primary-light: #6366F1;
            --primary-dark: #3730A3;
            --secondary: #10B981;
            --secondary-light: #34D399;
            --warning: #F59E0B;
            --danger: #EF4444;
            --success: #10B981;
            --info: #3B82F6;
            
            /* Neutrals */
            --dark: #0F172A;
            --dark-light: #1E293B;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --gray-900: #0F172A;
            
            /* Backgrounds */
            --bg-primary: #FAFAFB;
            --bg-secondary: #FFFFFF;
            --bg-tertiary: #F8FAFC;
            
            /* Shadows */
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            
            /* Border Radius */
            --radius-sm: 6px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --radius-xl: 20px;
            
            /* Transitions */
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background-color: var(--bg-primary);
            color: var(--gray-900);
            line-height: 1.6;
            font-size: 14px;
        }

        /* Layout */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--bg-secondary);
            border-right: 1px solid var(--gray-200);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 2rem 2rem 2rem;
            border-bottom: 1px solid var(--gray-200);
            margin-bottom: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 24px;
            font-weight: 800;
            color: var(--primary);
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
        }

        .nav-menu {
            list-style: none;
            padding: 0 1rem;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--gray-600);
            text-decoration: none;
            border-radius: var(--radius-md);
            transition: var(--transition);
            font-weight: 500;
        }

        .nav-link:hover, .nav-link.active {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            transform: translateX(4px);
        }

        .nav-link i {
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: var(--bg-primary);
        }

        .top-bar {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--gray-200);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: var(--gray-900);
        }

        .top-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            transition: var(--transition);
            font-size: 14px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-secondary {
            background: var(--gray-100);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
        }

        .btn-secondary:hover {
            background: var(--gray-200);
        }

        .status-indicator {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: var(--gray-600);
            font-weight: 500;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--success);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.7; transform: scale(1.1); }
        }

        /* Content Area */
        .content-area {
            padding: 2rem;
        }

        /* Metrics Grid */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 24px;
            margin-bottom: 2rem;
        }

        .metric-card {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 2rem;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .metric-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-xl);
        }

        .metric-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
        }

        .metric-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .metric-icon {
            width: 56px;
            height: 56px;
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
        }

        .metric-number {
            font-size: 48px;
            font-weight: 800;
            color: var(--gray-900);
            margin-bottom: 8px;
            line-height: 1;
        }

        .metric-label {
            font-size: 16px;
            color: var(--gray-600);
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .metric-change {
            font-size: 14px;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .positive { 
            color: var(--success); 
            background: rgba(16, 185, 129, 0.1);
        }

        .negative { 
            color: var(--danger); 
            background: rgba(239, 68, 68, 0.1);
        }

        /* Main Grid */
        .main-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .section-card {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 2rem;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--gray-200);
        }

        .section-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--gray-900);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Filters */
        .filters {
            display: flex;
            gap: 8px;
            margin-bottom: 1.5rem;
            padding: 8px;
            background: var(--gray-100);
            border-radius: var(--radius-md);
        }

        .filter-btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--radius-sm);
            background: transparent;
            color: var(--gray-600);
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: var(--transition);
        }

        .filter-btn:hover {
            background: var(--gray-200);
        }

        .filter-btn.active {
            background: var(--primary);
            color: white;
        }

        /* Employee Cards */
        .employee-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .employee-card {
            display: flex;
            align-items: center;
            padding: 1.5rem;
            border-radius: var(--radius-md);
            background: var(--bg-tertiary);
            border: 2px solid transparent;
            transition: var(--transition);
            position: relative;
        }

        .employee-card:hover {
            transform: translateX(8px);
            box-shadow: var(--shadow-md);
        }

        .employee-card.active {
            border-color: var(--success);
            background: rgba(16, 185, 129, 0.05);
        }

        .employee-card.busy {
            border-color: var(--danger);
            background: rgba(239, 68, 68, 0.05);
        }

        .employee-card.away {
            border-color: var(--warning);
            background: rgba(245, 158, 11, 0.05);
        }

        .employee-card.offline {
            border-color: var(--gray-300);
            background: var(--gray-100);
            opacity: 0.7;
        }

        .employee-avatar {
            width: 60px;
            height: 60px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 20px;
            margin-right: 1.5rem;
            position: relative;
            box-shadow: var(--shadow-md);
        }

        .status-dot-mini {
            position: absolute;
            bottom: -2px;
            right: -2px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            border: 3px solid white;
            background: var(--gray-400);
        }

        .employee-card.active .status-dot-mini {
            background: var(--success);
            animation: pulse-green 2s infinite;
        }

        .employee-card.busy .status-dot-mini {
            background: var(--danger);
            animation: pulse-red 2s infinite;
        }

        .employee-card.away .status-dot-mini {
            background: var(--warning);
        }

        @keyframes pulse-green {
            0%, 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
            50% { box-shadow: 0 0 0 8px rgba(16, 185, 129, 0); }
        }

        @keyframes pulse-red {
            0%, 100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7); }
            50% { box-shadow: 0 0 0 8px rgba(239, 68, 68, 0); }
        }

        .employee-info {
            flex: 1;
        }

        .employee-name {
            font-weight: 700;
            font-size: 16px;
            margin-bottom: 4px;
            color: var(--gray-900);
        }

        .employee-role {
            font-size: 14px;
            color: var(--gray-600);
            margin-bottom: 12px;
        }

        .employee-stats {
            display: flex;
            gap: 16px;
        }

        .stat-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 8px 12px;
            background: var(--bg-secondary);
            border-radius: var(--radius-sm);
            min-width: 70px;
            box-shadow: var(--shadow-sm);
        }

        .stat-label {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--gray-500);
            margin-bottom: 4px;
        }

        .stat-value {
            font-weight: 700;
            font-size: 14px;
            color: var(--gray-900);
        }

        .status-dropdown {
            position: absolute;
            top: 16px;
            right: 16px;
        }

        .status-select {
            border: 1px solid var(--gray-300);
            background: var(--bg-secondary);
            border-radius: var(--radius-sm);
            padding: 6px 10px;
            font-size: 12px;
            font-weight: 600;
            color: var(--gray-700);
            cursor: pointer;
        }

        /* Quick Actions */
        .quick-actions {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .action-btn {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px 20px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            text-decoration: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            width: 100%;
            text-align: left;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .action-btn i {
            width: 20px;
            text-align: center;
        }

        /* Activity Feed */
        .activity-feed {
            margin-top: 2rem;
        }

        .activity-item {
            display: flex;
            align-items: center;
            padding: 16px 0;
            border-bottom: 1px solid var(--gray-200);
            transition: var(--transition);
        }

        .activity-item:hover {
            background: var(--bg-tertiary);
            border-radius: var(--radius-sm);
            padding-left: 12px;
            padding-right: 12px;
        }

        .activity-icon {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--success);
            margin-right: 16px;
            animation: pulse 3s infinite;
        }

        .activity-text {
            font-size: 14px;
            color: var(--gray-700);
            flex: 1;
            font-weight: 500;
        }

        .activity-time {
            font-size: 12px;
            color: var(--gray-500);
            font-weight: 600;
        }

        /* Projects Section */
        .projects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 24px;
        }

        .project-card {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 2rem;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
            transition: var(--transition);
        }

        .project-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-lg);
        }

        .project-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .project-name {
            font-weight: 700;
            font-size: 18px;
            color: var(--gray-900);
        }

        .priority-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .priority-high { background: rgba(239, 68, 68, 0.1); color: var(--danger); }
        .priority-medium { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
        .priority-low { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .priority-urgent { background: rgba(147, 51, 234, 0.1); color: #9333EA; }

        .progress-container {
            margin-bottom: 1rem;
        }

        .progress-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        .progress-label {
            font-size: 14px;
            color: var(--gray-600);
            font-weight: 600;
        }

        .progress-value {
            font-size: 14px;
            color: var(--gray-900);
            font-weight: 700;
        }

        .progress-bar {
            height: 8px;
            background: var(--gray-200);
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            border-radius: 4px;
            transition: all 1s ease;
        }

        .progress-0-25 { background: linear-gradient(90deg, var(--danger), #F87171); }
        .progress-26-50 { background: linear-gradient(90deg, var(--warning), #FBBF24); }
        .progress-51-75 { background: linear-gradient(90deg, #EAB308, var(--warning)); }
        .progress-76-100 { background: linear-gradient(90deg, var(--success), var(--secondary-light)); }

        .project-description {
            font-size: 14px;
            color: var(--gray-600);
            line-height: 1.5;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: var(--bg-secondary);
            margin: 5% auto;
            padding: 2rem;
            border-radius: var(--radius-xl);
            width: 90%;
            max-width: 500px;
            box-shadow: var(--shadow-xl);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .modal-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--gray-900);
        }

        .close {
            font-size: 28px;
            cursor: pointer;
            color: var(--gray-400);
            transition: var(--transition);
        }

        .close:hover {
            color: var(--gray-600);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--gray-700);
        }

        .form-input, .form-select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 14px;
            transition: var(--transition);
            background: var(--bg-secondary);
        }

        .form-input:focus, .form-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        .form-submit {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            width: 100%;
            font-size: 16px;
        }

        .form-submit:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        /* Message Styles */
        .message {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 16px 24px;
            border-radius: var(--radius-md);
            font-weight: 600;
            z-index: 1001;
            box-shadow: var(--shadow-lg);
            backdrop-filter: blur(10px);
        }

        .message.success {
            background: rgba(16, 185, 129, 0.9);
            color: white;
        }

        .message.error {
            background: rgba(239, 68, 68, 0.9);
            color: white;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: var(--transition);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .metrics-grid {
                grid-template-columns: 1fr;
            }
            
            .main-grid {
                grid-template-columns: 1fr;
            }
            
            .projects-grid {
                grid-template-columns: 1fr;
            }
            
            .top-bar {
                padding: 1rem;
            }
            
            .content-area {
                padding: 1rem;
            }
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--gray-100);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--gray-300);
            border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--gray-400);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Modern Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-paw"></i>
                    </div>
                    <span>Foxhole</span>
                </div>
            </div>
            
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="#" class="nav-link active">
                            <i class="fas fa-chart-pie"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-users"></i>
                            <span>Team</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-project-diagram"></i>
                            <span>Projects</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-tasks"></i>
                            <span>Tasks</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-chart-line"></i>
                            <span>Analytics</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">
                            <i class="fas fa-cog"></i>
                            <span>Settings</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="top-bar">
                <div>
                    <h1 class="page-title">Dashboard</h1>
                </div>
                <div class="top-actions">
                    <button class="btn btn-secondary" onclick="openModal('employeeModal')">
                        <i class="fas fa-user-plus"></i>
                        Add Employee
                    </button>
                    <button class="btn btn-primary" onclick="openModal('projectModal')">
                        <i class="fas fa-plus"></i>
                        New Project
                    </button>
                    <div class="status-indicator">
                        <div class="status-dot"></div>
                        <span>Live Updates</span>
                    </div>
                </div>
            </header>

            <!-- Message Display -->
            <?php if (isset($message)): ?>
            <div class="message <?= strpos($message, '✅') !== false ? 'success' : 'error' ?>" id="message">
                <?= $message ?>
            </div>
            <?php endif; ?>

            <!-- Content Area -->
            <div class="content-area">
                <!-- Metrics Grid -->
                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-header">
                            <div class="metric-icon">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div class="metric-number"><?= $stats['active_employees'] ?></div>
                        <div class="metric-label">Active Today</div>
                        <div class="metric-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +2 from yesterday
                        </div>
                    </div>
                    
                    <div class="metric-card">
                        <div class="metric-header">
                            <div class="metric-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                        <div class="metric-number"><?= $stats['completed_tasks'] ?></div>
                        <div class="metric-label">Tasks Completed</div>
                        <div class="metric-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +15% this week
                        </div>
                    </div>
                    
                    <div class="metric-card">
                        <div class="metric-header">
                            <div class="metric-icon">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                        </div>
                        <div class="metric-number"><?= $stats['avg_productivity'] ?>%</div>
                        <div class="metric-label">Avg Productivity</div>
                        <div class="metric-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +5% this month
                        </div>
                    </div>
                    
                    <div class="metric-card">
                        <div class="metric-header">
                            <div class="metric-icon">
                                <i class="fas fa-folder-open"></i>
                            </div>
                        </div>
                        <div class="metric-number"><?= $stats['total_projects'] ?></div>
                        <div class="metric-label">Active Projects</div>
                        <div class="metric-change positive">
                            <i class="fas fa-arrow-up"></i>
                            2 new this week
                        </div>
                    </div>
                </div>

                <!-- Main Grid -->
                <div class="main-grid">
                    <!-- Team Status -->
                    <div class="section-card">
                        <div class="section-header">
                            <h2 class="section-title">
                                <i class="fas fa-users"></i>
                                Team Status
                            </h2>
                        </div>
                        
                        <div class="filters">
                            <button class="filter-btn active" onclick="filterEmployees('all')">
                                All (<?= count($employees_data) ?>)
                            </button>
                            <button class="filter-btn" onclick="filterEmployees('active')">Active</button>
                            <button class="filter-btn" onclick="filterEmployees('busy')">Busy</button>
                            <button class="filter-btn" onclick="filterEmployees('freelancers')">Freelancers</button>
                        </div>
                        
                        <div class="employee-list" id="employee-list">
                            <?php foreach ($employees_data as $emp): ?>
                            <div class="employee-card <?= $emp['status'] ?>" data-type="<?= $emp['type'] ?>" data-status="<?= $emp['status'] ?>">
                                <div class="employee-avatar">
                                    <?= strtoupper(substr($emp['name'], 0, 1) . substr(strstr($emp['name'], ' '), 1, 1)) ?>
                                    <div class="status-dot-mini"></div>
                                </div>
                                <div class="employee-info">
                                    <div class="employee-name"><?= htmlspecialchars($emp['name']) ?></div>
                                    <div class="employee-role"><?= htmlspecialchars($emp['role']) ?></div>
                                    <div class="employee-stats">
                                        <div class="stat-item">
                                            <div class="stat-label">Tasks</div>
                                            <div class="stat-value"><?= $emp['task_count'] ?: 0 ?></div>
                                        </div>
                                        <div class="stat-item">
                                            <div class="stat-label">Hours</div>
                                            <div class="stat-value"><?= number_format($emp['hours_today'] ?: 0, 1) ?>h</div>
                                        </div>
                                        <div class="stat-item">
                                            <div class="stat-label">Type</div>
                                            <div class="stat-value"><?= $emp['type'] === 'employee' ? '👤' : '🔧' ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="status-dropdown">
                                    <select class="status-select" onchange="updateStatus(<?= $emp['id'] ?>, this.value)">
                                        <option value="active" <?= $emp['status'] === 'active' ? 'selected' : '' ?>>🟢 Active</option>
                                        <option value="busy" <?= $emp['status'] === 'busy' ? 'selected' : '' ?>>🔴 Busy</option>
                                        <option value="away" <?= $emp['status'] === 'away' ? 'selected' : '' ?>>🟡 Away</option>
                                        <option value="offline" <?= $emp['status'] === 'offline' ? 'selected' : '' ?>>⚪ Offline</option>
                                    </select>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Quick Actions & Activity -->
                    <div class="section-card">
                        <div class="section-header">
                            <h2 class="section-title">
                                <i class="fas fa-bolt"></i>
                                Quick Actions
                            </h2>
                        </div>
                        
                        <div class="quick-actions">
                            <a href="https://clickup.com" class="action-btn" target="_blank">
                                <i class="fas fa-external-link-alt"></i>
                                Open ClickUp
                            </a>
                            <a href="https://notion.so" class="action-btn" target="_blank">
                                <i class="fas fa-file-alt"></i>
                                Open Notion
                            </a>
                            <button class="action-btn" onclick="generateReport()">
                                <i class="fas fa-chart-pie"></i>
                                Generate Report
                            </button>
                            <button class="action-btn" onclick="scheduleStandup()">
                                <i class="fas fa-calendar-plus"></i>
                                Schedule Standup
                            </button>
                        </div>

                        <div class="activity-feed">
                            <h3 class="section-title">
                                <i class="fas fa-activity"></i>
                                Recent Activity
                            </h3>
                            <div id="activity-feed">
                                <?php foreach (array_slice($activities_data, 0, 8) as $activity): ?>
                                <div class="activity-item">
                                    <div class="activity-icon"></div>
                                    <div class="activity-text"><?= htmlspecialchars($activity['activity']) ?></div>
                                    <div class="activity-time"><?= $activity['time_formatted'] ?: 'Recently' ?></div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Projects Section -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-rocket"></i>
                            Active Projects
                        </h2>
                    </div>
                    
                    <div class="projects-grid">
                        <?php foreach ($projects_data as $project): ?>
                        <div class="project-card">
                            <div class="project-header">
                                <div class="project-name"><?= htmlspecialchars($project['name']) ?></div>
                                <div class="priority-badge priority-<?= $project['priority'] ?>">
                                    <?= strtoupper($project['priority']) ?>
                                </div>
                            </div>
                            <div class="progress-container">
                                <div class="progress-header">
                                    <span class="progress-label">Progress</span>
                                    <span class="progress-value"><?= $project['progress'] ?>%</span>
                                </div>
                                <div class="progress-bar">
                                    <div class="progress-fill <?= getProgressClass($project['progress']) ?>" 
                                         style="width: <?= $project['progress'] ?>%"></div>
                                </div>
                            </div>
                            <div class="project-description">
                                <?= htmlspecialchars($project['description'] ?: 'No description available') ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Add Employee Modal -->
    <div id="employeeModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">Add New Employee</div>
                <span class="close" onclick="closeModal('employeeModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_employee">
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" name="name" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Role</label>
                    <input type="text" name="role" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Type</label>
                    <select name="type" class="form-select" required>
                        <option value="employee">Employee</option>
                        <option value="freelancer">Freelancer</option>
                    </select>
                </div>
                <button type="submit" class="form-submit">Add Employee</button>
            </form>
        </div>
    </div>

    <!-- Add Project Modal -->
    <div id="projectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title">Add New Project</div>
                <span class="close" onclick="closeModal('projectModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_project">
                <div class="form-group">
                    <label class="form-label">Project Name</label>
                    <input type="text" name="name" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <input type="text" name="description" class="form-input">
                </div>
                <div class="form-group">
                    <label class="form-label">Client</label>
                    <input type="text" name="client" class="form-input">
                </div>
                <div class="form-group">
                    <label class="form-label">Priority</label>
                    <select name="priority" class="form-select" required>
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                    </select>
                </div>
                <button type="submit" class="form-submit">Add Project</button>
            </form>
        </div>
    </div>

    <script>
        // Modal functions
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Filter employees
        function filterEmployees(filter) {
            const employees = document.querySelectorAll('.employee-card');
            const buttons = document.querySelectorAll('.filter-btn');
            
            // Update active button
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            // Filter employees
            employees.forEach(emp => {
                const type = emp.dataset.type;
                const status = emp.dataset.status;
                
                let show = false;
                if (filter === 'all') show = true;
                else if (filter === 'freelancers') show = (type === 'freelancer');
                else show = (status === filter);
                
                emp.style.display = show ? 'flex' : 'none';
            });
        }

        // Update employee status
        function updateStatus(employeeId, status) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'update_status';
            
            const empInput = document.createElement('input');
            empInput.name = 'employee_id';
            empInput.value = employeeId;
            
            const statusInput = document.createElement('input');
            statusInput.name = 'status';
            statusInput.value = status;
            
            form.appendChild(actionInput);
            form.appendChild(empInput);
            form.appendChild(statusInput);
            
            document.body.appendChild(form);
            form.submit();
        }

        // Utility functions
        function generateReport() {
            alert('📊 Generating comprehensive team productivity report...\n\nThis would include:\n• Individual performance metrics\n• Project completion rates\n• Time tracking analysis\n• Team efficiency insights');
        }

        function scheduleStandup() {
            alert('📅 Opening calendar integration...\n\nThis would:\n• Connect to your calendar\n• Schedule team standup\n• Send invites to active team members\n• Set recurring meetings');
        }

        // Auto-hide message
        setTimeout(() => {
            const message = document.getElementById('message');
            if (message) {
                message.style.opacity = '0';
                setTimeout(() => message.remove(), 300);
            }
        }, 3000);

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey || e.metaKey) {
                switch(e.key) {
                    case '1': e.preventDefault(); filterEmployees('all'); break;
                    case '2': e.preventDefault(); filterEmployees('active'); break;
                    case '3': e.preventDefault(); filterEmployees('busy'); break;
                    case '4': e.preventDefault(); filterEmployees('freelancers'); break;
                    case 'n': e.preventDefault(); openModal('employeeModal'); break;
                    case 'p': e.preventDefault(); openModal('projectModal'); break;
                    case 'r': e.preventDefault(); location.reload(); break;
                }
            }
        });

        // Auto-refresh every 30 seconds
        setInterval(() => {
            location.reload();
        }, 30000);

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>

<?php
function getProgressClass($progress) {
    if ($progress <= 25) return 'progress-0-25';
    if ($progress <= 50) return 'progress-26-50';
    if ($progress <= 75) return 'progress-51-75';
    return 'progress-76-100';
}
?>