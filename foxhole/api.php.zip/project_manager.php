<?php
// project_manager.php - Dedicated Project Manager Interface
require_once 'config-2.php';
require_once 'api.php';

// Handle form submissions
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $api = new DashboardAPI();
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add_employee':
            $result = $api->addEmployee($_POST['name'], $_POST['email'], $_POST['role'], $_POST['type']);
            $message = $result ? "✅ Employee added successfully!" : "❌ Error adding employee.";
            $messageType = $result ? 'success' : 'error';
            break;
            
        case 'update_employee_status':
            $result = $api->updateEmployeeStatus($_POST['employee_id'], $_POST['status']);
            $message = $result ? "✅ Status updated!" : "❌ Error updating status.";
            $messageType = $result ? 'success' : 'error';
            break;
            
        case 'add_project':
            $result = $api->addProject($_POST['name'], $_POST['description'], $_POST['client'], $_POST['priority']);
            $message = $result ? "✅ Project added successfully!" : "❌ Error adding project.";
            $messageType = $result ? 'success' : 'error';
            break;
            
        case 'add_task':
            $result = $api->addTask($_POST['employee_id'], $_POST['project_id'], $_POST['title'], $_POST['description'], $_POST['priority'], $_POST['due_date'], $_POST['estimated_hours']);
            $message = $result ? "✅ Task added successfully!" : "❌ Error adding task.";
            $messageType = $result ? 'success' : 'error';
            break;
            
        case 'bulk_status_update':
            $employee_ids = $_POST['employee_ids'] ?? [];
            $new_status = $_POST['bulk_status'] ?? '';
            $count = 0;
            foreach ($employee_ids as $emp_id) {
                if ($api->updateEmployeeStatus($emp_id, $new_status)) {
                    $count++;
                }
            }
            $message = "✅ Updated status for {$count} employees.";
            $messageType = 'success';
            break;
            
        case 'log_activity':
            $result = $api->logActivity($_POST['employee_id'], $_POST['activity_text'], $_POST['activity_type']);
            $message = $result ? "✅ Activity logged!" : "❌ Error logging activity.";
            $messageType = $result ? 'success' : 'error';
            break;
    }
}

// Get data for display
$api = new DashboardAPI();
$employees_data = $api->getEmployees();
$projects_data = $api->getProjects();
$tasks_data = $api->getTasks();
$stats = $api->getDashboardStats();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foxhole - Project Manager Interface</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #4F46E5;
            --primary-light: #6366F1;
            --secondary: #10B981;
            --warning: #F59E0B;
            --danger: #EF4444;
            --success: #10B981;
            --info: #3B82F6;
            
            --dark: #0F172A;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-900: #0F172A;
            
            --bg-primary: #FAFAFB;
            --bg-secondary: #FFFFFF;
            
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius-lg: 16px;
            --radius-md: 12px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--gray-900);
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }

        .header {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 28px;
            font-weight: 800;
            color: var(--primary);
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }

        .header-info {
            display: flex;
            flex-direction: column;
        }

        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--gray-900);
        }

        .page-subtitle {
            font-size: 14px;
            color: var(--gray-600);
        }

        .header-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-warning {
            background: var(--warning);
            color: white;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-secondary {
            background: var(--gray-200);
            color: var(--gray-700);
        }

        .message {
            margin-bottom: 2rem;
            padding: 16px 20px;
            border-radius: var(--radius-md);
            font-weight: 600;
        }

        .message.success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.3);
        }

        .message.error {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--bg-secondary);
            border-radius: var(--radius-md);
            padding: 1.5rem;
            text-align: center;
            box-shadow: var(--shadow-lg);
        }

        .stat-number {
            font-size: 32px;
            font-weight: 800;
            color: var(--primary);
            margin-bottom: 0.5rem;
        }

        .stat-label {
            font-size: 14px;
            color: var(--gray-600);
            font-weight: 600;
        }

        .main-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .section-card {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 2rem;
            box-shadow: var(--shadow-lg);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .section-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--gray-900);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--gray-700);
        }

        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-textarea {
            min-height: 100px;
            resize: vertical;
        }

        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        .employee-list {
            max-height: 400px;
            overflow-y: auto;
        }

        .employee-item {
            display: flex;
            align-items: center;
            padding: 1rem;
            border-bottom: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .employee-item:hover {
            background: var(--gray-100);
        }

        .employee-checkbox {
            margin-right: 1rem;
        }

        .employee-avatar {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-md);
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            margin-right: 1rem;
        }

        .employee-info {
            flex: 1;
        }

        .employee-name {
            font-weight: 600;
            margin-bottom: 4px;
        }

        .employee-role {
            font-size: 12px;
            color: var(--gray-600);
        }

        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .status-active { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .status-busy { background: rgba(239, 68, 68, 0.1); color: var(--danger); }
        .status-away { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
        .status-offline { background: var(--gray-200); color: var(--gray-600); }

        .bulk-actions {
            background: var(--gray-100);
            padding: 1rem;
            border-radius: var(--radius-md);
            margin-bottom: 1rem;
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .tabs {
            display: flex;
            border-bottom: 2px solid var(--gray-200);
            margin-bottom: 2rem;
        }

        .tab {
            padding: 12px 24px;
            border: none;
            background: none;
            cursor: pointer;
            font-weight: 600;
            color: var(--gray-600);
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
        }

        .tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .task-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            border: 1px solid var(--gray-200);
            border-radius: var(--radius-md);
            margin-bottom: 1rem;
        }

        .task-info h4 {
            margin-bottom: 0.5rem;
            color: var(--gray-900);
        }

        .task-meta {
            font-size: 12px;
            color: var(--gray-600);
        }

        .priority-high { border-left: 4px solid var(--danger); }
        .priority-medium { border-left: 4px solid var(--warning); }
        .priority-low { border-left: 4px solid var(--success); }

        @media (max-width: 768px) {
            .main-grid {
                grid-template-columns: 1fr;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-left">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-tasks"></i>
                    </div>
                </div>
                <div class="header-info">
                    <div class="page-title">Project Manager Interface</div>
                    <div class="page-subtitle">Team & Project Data Management</div>
                </div>
            </div>
            <div class="header-actions">
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="fas fa-chart-pie"></i>
                    CEO Dashboard
                </a>
                <button class="btn btn-primary" onclick="refreshData()">
                    <i class="fas fa-sync-alt"></i>
                    Refresh Data
                </button>
            </div>
        </div>

        <!-- Message Display -->
        <?php if ($message): ?>
        <div class="message <?= $messageType ?>">
            <?= $message ?>
        </div>
        <?php endif; ?>

        <!-- Quick Stats -->
        <div class="quick-stats">
            <div class="stat-card">
                <div class="stat-number"><?= count($employees_data) ?></div>
                <div class="stat-label">Total Team Members</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $stats['active_employees'] ?></div>
                <div class="stat-label">Active Today</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= count($projects_data) ?></div>
                <div class="stat-label">Active Projects</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= count($tasks_data) ?></div>
                <div class="stat-label">Total Tasks</div>
            </div>
        </div>

        <!-- Tab Navigation -->
        <div class="tabs">
            <button class="tab active" onclick="showTab('team-management')">
                <i class="fas fa-users"></i> Team Management
            </button>
            <button class="tab" onclick="showTab('project-management')">
                <i class="fas fa-project-diagram"></i> Project Management
            </button>
            <button class="tab" onclick="showTab('task-management')">
                <i class="fas fa-tasks"></i> Task Management
            </button>
            <button class="tab" onclick="showTab('activity-log')">
                <i class="fas fa-history"></i> Activity Log
            </button>
        </div>

        <!-- Team Management Tab -->
        <div id="team-management" class="tab-content active">
            <div class="main-grid">
                <!-- Add Employee Form -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-user-plus"></i>
                            Add Team Member
                        </h2>
                    </div>
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="add_employee">
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Full Name *</label>
                                <input type="text" name="name" class="form-input" required 
                                       placeholder="John Doe">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Email *</label>
                                <input type="email" name="email" class="form-input" required 
                                       placeholder="john@neofoxmedia.com">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Role/Position *</label>
                                <input type="text" name="role" class="form-input" required 
                                       placeholder="e.g., Video Editor, Designer">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Employment Type</label>
                                <select name="type" class="form-select" required>
                                    <option value="employee">Full-time Employee</option>
                                    <option value="freelancer">Freelancer/Contractor</option>
                                </select>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-plus"></i>
                            Add Team Member
                        </button>
                    </form>
                </div>

                <!-- Team List & Management -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-users"></i>
                            Team Overview (<?= count($employees_data) ?>)
                        </h2>
                    </div>
                    
                    <!-- Bulk Actions -->
                    <div class="bulk-actions">
                        <span style="font-weight: 600;">Bulk Actions:</span>
                        <select id="bulk-status" class="form-select" style="width: auto;">
                            <option value="active">Set Active</option>
                            <option value="busy">Set Busy</option>
                            <option value="away">Set Away</option>
                            <option value="offline">Set Offline</option>
                        </select>
                        <button class="btn btn-warning" onclick="bulkUpdateStatus()">
                            <i class="fas fa-edit"></i>
                            Update Selected
                        </button>
                    </div>
                    
                    <div class="employee-list">
                        <?php foreach ($employees_data as $emp): ?>
                        <div class="employee-item">
                            <input type="checkbox" class="employee-checkbox" value="<?= $emp['id'] ?>">
                            <div class="employee-avatar">
                                <?= strtoupper(substr($emp['name'], 0, 1) . (strstr($emp['name'], ' ') ? substr(strstr($emp['name'], ' '), 1, 1) : '')) ?>
                            </div>
                            <div class="employee-info">
                                <div class="employee-name"><?= htmlspecialchars($emp['name']) ?></div>
                                <div class="employee-role"><?= htmlspecialchars($emp['role']) ?> • <?= ucfirst($emp['type']) ?></div>
                            </div>
                            <div class="status-badge status-<?= $emp['status'] ?>">
                                <?= ucfirst($emp['status']) ?>
                            </div>
                            <select class="form-select" style="width: 120px; margin-left: 1rem;" 
                                    onchange="updateEmployeeStatus(<?= $emp['id'] ?>, this.value)">
                                <option value="active" <?= $emp['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                                <option value="busy" <?= $emp['status'] === 'busy' ? 'selected' : '' ?>>Busy</option>
                                <option value="away" <?= $emp['status'] === 'away' ? 'selected' : '' ?>>Away</option>
                                <option value="offline" <?= $emp['status'] === 'offline' ? 'selected' : '' ?>>Offline</option>
                            </select>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Project Management Tab -->
        <div id="project-management" class="tab-content">
            <div class="main-grid">
                <!-- Add Project Form -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-plus-circle"></i>
                            Add New Project
                        </h2>
                    </div>
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="add_project">
                        
                        <div class="form-group">
                            <label class="form-label">Project Name *</label>
                            <input type="text" name="name" class="form-input" required 
                                   placeholder="e.g., Brand Redesign for ABC Corp">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Client/Company</label>
                            <input type="text" name="client" class="form-input" 
                                   placeholder="Client name or internal project">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Priority Level</label>
                            <select name="priority" class="form-select" required>
                                <option value="low">Low Priority</option>
                                <option value="medium" selected>Medium Priority</option>
                                <option value="high">High Priority</option>
                                <option value="urgent">Urgent</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Project Description</label>
                            <textarea name="description" class="form-textarea" 
                                      placeholder="Brief description of the project scope and objectives..."></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-plus"></i>
                            Create Project
                        </button>
                    </form>
                </div>

                <!-- Projects List -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-project-diagram"></i>
                            Active Projects (<?= count($projects_data) ?>)
                        </h2>
                    </div>
                    
                    <div style="max-height: 400px; overflow-y: auto;">
                        <?php foreach ($projects_data as $project): ?>
                        <div class="task-item priority-<?= $project['priority'] ?>">
                            <div class="task-info">
                                <h4><?= htmlspecialchars($project['name']) ?></h4>
                                <div class="task-meta">
                                    Client: <?= htmlspecialchars($project['client'] ?: 'Internal') ?> • 
                                    Priority: <?= ucfirst($project['priority']) ?> • 
                                    Progress: <?= $project['progress'] ?>%
                                </div>
                            </div>
                            <div class="status-badge status-<?= $project['status'] ?>">
                                <?= ucfirst($project['status']) ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Task Management Tab -->
        <div id="task-management" class="tab-content">
            <div class="main-grid">
                <!-- Add Task Form -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-tasks"></i>
                            Add New Task
                        </h2>
                    </div>
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="add_task">
                        
                        <div class="form-group">
                            <label class="form-label">Task Title *</label>
                            <input type="text" name="title" class="form-input" required 
                                   placeholder="e.g., Create logo concepts">
                        </div>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Assign to Employee</label>
                                <select name="employee_id" class="form-select">
                                    <option value="">Unassigned</option>
                                    <?php foreach ($employees_data as $emp): ?>
                                    <option value="<?= $emp['id'] ?>"><?= htmlspecialchars($emp['name']) ?> (<?= $emp['role'] ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Project</label>
                                <select name="project_id" class="form-select">
                                    <option value="">No Project</option>
                                    <?php foreach ($projects_data as $proj): ?>
                                    <option value="<?= $proj['id'] ?>"><?= htmlspecialchars($proj['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Priority</label>
                                <select name="priority" class="form-select">
                                    <option value="low">Low</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="high">High</option>
                                    <option value="urgent">Urgent</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Due Date</label>
                                <input type="date" name="due_date" class="form-input">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Estimated Hours</label>
                            <input type="number" name="estimated_hours" class="form-input" 
                                   step="0.5" min="0" placeholder="e.g., 4.5">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-textarea" 
                                      placeholder="Detailed task description..."></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-plus"></i>
                            Create Task
                        </button>
                    </form>
                </div>

                <!-- Tasks Overview -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-list"></i>
                            Recent Tasks (<?= count($tasks_data) ?>)
                        </h2>
                    </div>
                    
                    <div style="max-height: 400px; overflow-y: auto;">
                        <?php foreach (array_slice($tasks_data, 0, 10) as $task): ?>
                        <div class="task-item priority-<?= $task['priority'] ?>">
                            <div class="task-info">
                                <h4><?= htmlspecialchars($task['title']) ?></h4>
                                <div class="task-meta">
                                    <?= $task['employee_name'] ? 'Assigned to: ' . htmlspecialchars($task['employee_name']) : 'Unassigned' ?> • 
                                    <?= $task['project_name'] ? 'Project: ' . htmlspecialchars($task['project_name']) : 'No Project' ?>
                                </div>
                            </div>
                            <div class="status-badge status-<?= $task['status'] ?>">
                                <?= ucfirst(str_replace('_', ' ', $task['status'])) ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Activity Log Tab -->
        <div id="activity-log" class="tab-content">
            <div class="main-grid">
                <!-- Log Activity Form -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-plus"></i>
                            Log Team Activity
                        </h2>
                    </div>
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="log_activity">
                        
                        <div class="form-group">
                            <label class="form-label">Team Member</label>
                            <select name="employee_id" class="form-select" required>
                                <option value="">Select team member...</option>
                                <?php foreach ($employees_data as $emp): ?>
                                <option value="<?= $emp['id'] ?>"><?= htmlspecialchars($emp['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Activity Type</label>
                            <select name="activity_type" class="form-select" required>
                                <option value="general">General Activity</option>
                                <option value="task_start">Started Task</option>
                                <option value="task_complete">Completed Task</option>
                                <option value="break">Break/Time Off</option>
                                <option value="meeting">Meeting/Call</option>
                                <option value="status_change">Status Change</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Activity Description</label>
                            <textarea name="activity_text" class="form-textarea" required 
                                      placeholder="Describe what happened..."></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save"></i>
                            Log Activity
                        </button>
                    </form>
                </div>

                <!-- Recent Activities -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-history"></i>
                            Recent Activities
                        </h2>
                    </div>
                    
                    <div style="max-height: 400px; overflow-y: auto;">
                        <?php 
                        $activities = $api->getRecentActivity(20);
                        foreach ($activities as $activity): 
                        ?>
                        <div class="task-item" style="border-left: 4px solid var(--info);">
                            <div class="task-info">
                                <h4><?= htmlspecialchars($activity['activity']) ?></h4>
                                <div class="task-meta">
                                    <?= $activity['employee_name'] ? htmlspecialchars($activity['employee_name']) : 'System' ?> • 
                                    <?= $activity['time_formatted'] ?>
                                </div>
                            </div>
                            <div class="status-badge status-active">
                                <?= ucfirst($activity['type']) ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Tab Management
        function showTab(tabId) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(tabId).classList.add('active');
            
            // Add active class to clicked tab
            event.target.classList.add('active');
        }

        // Update employee status
        function updateEmployeeStatus(employeeId, status) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'update_employee_status';
            
            const empInput = document.createElement('input');
            empInput.name = 'employee_id';
            empInput.value = employeeId;
            
            const statusInput = document.createElement('input');
            statusInput.name = 'status';
            statusInput.value = status;
            
            form.appendChild(actionInput);
            form.appendChild(empInput);
            form.appendChild(statusInput);
            
            document.body.appendChild(form);
            form.submit();
        }

        // Bulk status update
        function bulkUpdateStatus() {
            const selectedEmployees = Array.from(document.querySelectorAll('.employee-checkbox:checked'))
                .map(cb => cb.value);
            
            if (selectedEmployees.length === 0) {
                alert('Please select at least one employee');
                return;
            }
            
            const newStatus = document.getElementById('bulk-status').value;
            
            if (confirm(`Update status to "${newStatus}" for ${selectedEmployees.length} employee(s)?`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.name = 'action';
                actionInput.value = 'bulk_status_update';
                form.appendChild(actionInput);
                
                const statusInput = document.createElement('input');
                statusInput.name = 'bulk_status';
                statusInput.value = newStatus;
                form.appendChild(statusInput);
                
                selectedEmployees.forEach(empId => {
                    const empInput = document.createElement('input');
                    empInput.name = 'employee_ids[]';
                    empInput.value = empId;
                    form.appendChild(empInput);
                });
                
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Refresh data
        function refreshData() {
            location.reload();
        }

        // Auto-refresh every 2 minutes
        setInterval(() => {
            location.reload();
        }, 120000);
    </script>
</body>
</html>

<?php
// Add missing method to DashboardAPI class
if (!method_exists('DashboardAPI', 'addTask')) {
    // We'll need to add this method to api.php later
}
?>