<?php
// api_enhanced.php - Enhanced API with task management for Project Manager Interface
require_once 'config-2.php';

class DashboardAPI {
    private $db;
    
    public function __construct() {
        try {
            $this->db = new Database();
        } catch (Exception $e) {
            error_log("Database connection failed: " . $e->getMessage());
            $this->db = null;
        }
    }
    
    public function getEmployees() {
        if (!$this->db) {
            return [];
        }
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                SELECT e.*, 
                       COALESCE(COUNT(DISTINCT t.id), 0) as task_count,
                       COALESCE(SUM(t.hours_logged), 0) as hours_today,
                       MAX(COALESCE(t.last_activity, e.last_activity)) as last_activity,
                       CASE 
                           WHEN e.clickup_user_id IS NOT NULL THEN 'ClickUp'
                           WHEN e.notion_user_id IS NOT NULL THEN 'Notion'
                           ELSE 'Manual'
                       END as data_source
                FROM employees e 
                LEFT JOIN tasks t ON e.id = t.employee_id 
                    AND DATE(t.created_at) = CURDATE()
                GROUP BY e.id
                ORDER BY 
                    CASE e.status 
                        WHEN 'active' THEN 1 
                        WHEN 'busy' THEN 2 
                        WHEN 'away' THEN 3 
                        ELSE 4 
                    END,
                    e.name
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching employees: " . $e->getMessage());
            return [];
        }
    }
    
    public function getProjects() {
        if (!$this->db) {
            return [];
        }
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                SELECT p.*, 
                       COALESCE(COUNT(DISTINCT t.id), 0) as total_tasks,
                       COALESCE(COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END), 0) as completed_tasks,
                       CASE 
                           WHEN COUNT(DISTINCT t.id) > 0 
                           THEN ROUND((COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END) / COUNT(DISTINCT t.id)) * 100, 0)
                           ELSE 0 
                       END as progress,
                       CASE 
                           WHEN p.clickup_project_id IS NOT NULL THEN 'ClickUp'
                           WHEN p.notion_page_id IS NOT NULL THEN 'Notion'
                           ELSE 'Manual'
                       END as data_source,
                       GROUP_CONCAT(DISTINCT e.name ORDER BY e.name SEPARATOR ', ') as team_members
                FROM projects p 
                LEFT JOIN tasks t ON p.id = t.project_id 
                LEFT JOIN employees e ON t.employee_id = e.id
                WHERE p.status != 'completed'
                GROUP BY p.id
                ORDER BY 
                    CASE p.priority 
                        WHEN 'urgent' THEN 1 
                        WHEN 'high' THEN 2 
                        WHEN 'medium' THEN 3 
                        ELSE 4 
                    END,
                    p.name
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching projects: " . $e->getMessage());
            return [];
        }
    }
    
    public function getTasks($filters = []) {
        if (!$this->db) {
            return [];
        }
        
        try {
            $whereClause = "WHERE 1=1";
            $params = [];
            
            if (isset($filters['status'])) {
                $whereClause .= " AND t.status = ?";
                $params[] = $filters['status'];
            }
            
            if (isset($filters['employee_id'])) {
                $whereClause .= " AND t.employee_id = ?";
                $params[] = $filters['employee_id'];
            }
            
            if (isset($filters['project_id'])) {
                $whereClause .= " AND t.project_id = ?";
                $params[] = $filters['project_id'];
            }
            
            $stmt = $this->db->getConnection()->prepare("
                SELECT t.*, 
                       e.name as employee_name,
                       p.name as project_name,
                       CASE 
                           WHEN t.clickup_task_id IS NOT NULL THEN 'ClickUp'
                           ELSE 'Manual'
                       END as data_source
                FROM tasks t
                LEFT JOIN employees e ON t.employee_id = e.id
                LEFT JOIN projects p ON t.project_id = p.id
                {$whereClause}
                ORDER BY 
                    CASE t.priority 
                        WHEN 'urgent' THEN 1 
                        WHEN 'high' THEN 2 
                        WHEN 'medium' THEN 3 
                        ELSE 4 
                    END,
                    t.due_date ASC,
                    t.created_at DESC
            ");
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching tasks: " . $e->getMessage());
            return [];
        }
    }
    
    public function getRecentActivity($limit = 10) {
        if (!$this->db) {
            return [];
        }
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                SELECT al.*, e.name as employee_name,
                       CONCAT(
                           CASE 
                               WHEN TIMESTAMPDIFF(MINUTE, al.created_at, NOW()) < 60 
                               THEN CONCAT(TIMESTAMPDIFF(MINUTE, al.created_at, NOW()), 'm ago')
                               WHEN TIMESTAMPDIFF(HOUR, al.created_at, NOW()) < 24 
                               THEN CONCAT(TIMESTAMPDIFF(HOUR, al.created_at, NOW()), 'h ago')
                               ELSE CONCAT(TIMESTAMPDIFF(DAY, al.created_at, NOW()), 'd ago')
                           END
                       ) as time_formatted
                FROM activity_log al 
                LEFT JOIN employees e ON al.employee_id = e.id 
                ORDER BY al.created_at DESC 
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching activity: " . $e->getMessage());
            return [];
        }
    }
    
    public function updateEmployeeStatus($employee_id, $status) {
        if (!$this->db) {
            return false;
        }
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                UPDATE employees 
                SET status = ?, last_activity = NOW() 
                WHERE id = ?
            ");
            $result = $stmt->execute([$status, $employee_id]);
            
            // Log the activity
            if ($result) {
                $this->logActivity($employee_id, "Status changed to {$status}", 'status_change');
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Error updating employee status: " . $e->getMessage());
            return false;
        }
    }
    
    public function addEmployee($name, $email, $role, $type = 'employee') {
        if (!$this->db) {
            return false;
        }
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                INSERT INTO employees (name, email, role, type, status, created_at) 
                VALUES (?, ?, ?, ?, 'offline', NOW())
            ");
            $result = $stmt->execute([$name, $email, $role, $type]);
            
            if ($result) {
                $employee_id = $this->db->getConnection()->lastInsertId();
                $this->logActivity($employee_id, "New {$type} added to team", 'general');
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Error adding employee: " . $e->getMessage());
            return false;
        }
    }
    
    public function addProject($name, $description, $client, $priority = 'medium') {
        if (!$this->db) {
            return false;
        }
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                INSERT INTO projects (name, description, client, priority, status, created_at) 
                VALUES (?, ?, ?, ?, 'planning', NOW())
            ");
            return $stmt->execute([$name, $description, $client, $priority]);
        } catch (Exception $e) {
            error_log("Error adding project: " . $e->getMessage());
            return false;
        }
    }
    
    // NEW: Add Task Method for Project Manager Interface
    public function addTask($employee_id, $project_id, $title, $description = '', $priority = 'medium', $due_date = null, $estimated_hours = null) {
        if (!$this->db) {
            return false;
        }
        
        try {
            // Convert empty strings to null for foreign keys
            $employee_id = $employee_id ?: null;
            $project_id = $project_id ?: null;
            $due_date = $due_date ?: null;
            $estimated_hours = $estimated_hours ?: null;
            
            $stmt = $this->db->getConnection()->prepare("
                INSERT INTO tasks (employee_id, project_id, title, description, status, priority, estimated_hours, due_date, created_at, last_activity) 
                VALUES (?, ?, ?, ?, 'todo', ?, ?, ?, NOW(), NOW())
            ");
            $result = $stmt->execute([$employee_id, $project_id, $title, $description, $priority, $estimated_hours, $due_date]);
            
            if ($result && $employee_id) {
                $this->logActivity($employee_id, "New task assigned: {$title}", 'task_start');
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Error adding task: " . $e->getMessage());
            return false;
        }
    }
    
    // NEW: Update Task Status
    public function updateTaskStatus($task_id, $status) {
        if (!$this->db) {
            return false;
        }
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                UPDATE tasks 
                SET status = ?, last_activity = NOW() 
                WHERE id = ?
            ");
            $result = $stmt->execute([$status, $task_id]);
            
            // Log activity if task has an assignee
            if ($result) {
                $stmt = $this->db->getConnection()->prepare("
                    SELECT employee_id, title FROM tasks WHERE id = ?
                ");
                $stmt->execute([$task_id]);
                $task = $stmt->fetch();
                
                if ($task && $task['employee_id']) {
                    $this->logActivity($task['employee_id'], "Task '{$task['title']}' status changed to {$status}", 'task_complete');
                }
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Error updating task status: " . $e->getMessage());
            return false;
        }
    }
    
    // NEW: Get Employee Tasks
    public function getEmployeeTasks($employee_id, $status = null) {
        if (!$this->db) {
            return [];
        }
        
        try {
            $whereClause = "WHERE t.employee_id = ?";
            $params = [$employee_id];
            
            if ($status) {
                $whereClause .= " AND t.status = ?";
                $params[] = $status;
            }
            
            $stmt = $this->db->getConnection()->prepare("
                SELECT t.*, p.name as project_name 
                FROM tasks t
                LEFT JOIN projects p ON t.project_id = p.id
                {$whereClause}
                ORDER BY 
                    CASE t.priority 
                        WHEN 'urgent' THEN 1 
                        WHEN 'high' THEN 2 
                        WHEN 'medium' THEN 3 
                        ELSE 4 
                    END,
                    t.due_date ASC
            ");
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching employee tasks: " . $e->getMessage());
            return [];
        }
    }
    
    public function logActivity($employee_id, $activity, $type = 'general') {
        if (!$this->db) {
            return false;
        }
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                INSERT INTO activity_log (employee_id, activity, type, created_at) 
                VALUES (?, ?, ?, NOW())
            ");
            return $stmt->execute([$employee_id, $activity, $type]);
        } catch (Exception $e) {
            error_log("Error logging activity: " . $e->getMessage());
            return false;
        }
    }
    
    public function getDashboardStats() {
        if (!$this->db) {
            return [
                'total_employees' => 0,
                'active_employees' => 0,
                'total_projects' => 0,
                'completed_tasks' => 0,
                'avg_productivity' => 0
            ];
        }
        
        try {
            // Get employee stats
            $stmt = $this->db->getConnection()->prepare("
                SELECT 
                    COUNT(*) as total_employees,
                    COUNT(CASE WHEN status = 'active' THEN 1 END) as active_employees
                FROM employees
            ");
            $stmt->execute();
            $empStats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Get project stats
            $stmt = $this->db->getConnection()->prepare("
                SELECT COUNT(*) as total_projects FROM projects WHERE status != 'completed'
            ");
            $stmt->execute();
            $projStats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Get task stats
            $stmt = $this->db->getConnection()->prepare("
                SELECT 
                    COUNT(CASE WHEN status = 'completed' AND DATE(created_at) = CURDATE() THEN 1 END) as completed_tasks,
                    AVG(CASE WHEN hours_logged > 0 THEN (hours_logged / 8) * 100 ELSE 0 END) as avg_productivity
                FROM tasks 
                WHERE DATE(created_at) = CURDATE()
            ");
            $stmt->execute();
            $taskStats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return [
                'total_employees' => $empStats['total_employees'] ?: 0,
                'active_employees' => $empStats['active_employees'] ?: 0,
                'total_projects' => $projStats['total_projects'] ?: 0,
                'completed_tasks' => $taskStats['completed_tasks'] ?: 0,
                'avg_productivity' => round($taskStats['avg_productivity'] ?: 0)
            ];
        } catch (Exception $e) {
            error_log("Error getting dashboard stats: " . $e->getMessage());
            return [
                'total_employees' => 0,
                'active_employees' => 0,
                'total_projects' => 0,
                'completed_tasks' => 0,
                'avg_productivity' => 0
            ];
        }
    }
}

// ONLY run API endpoint logic if this file is accessed directly (not included)
if (basename($_SERVER['PHP_SELF']) === 'api_enhanced.php') {
    header('Content-Type: application/json');
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
        $api = new DashboardAPI();
        
        switch ($_GET['action']) {
            case 'employees':
                echo json_encode($api->getEmployees());
                break;
                
            case 'projects':
                echo json_encode($api->getProjects());
                break;
                
            case 'tasks':
                $filters = [];
                if (isset($_GET['status'])) $filters['status'] = $_GET['status'];
                if (isset($_GET['employee_id'])) $filters['employee_id'] = $_GET['employee_id'];
                if (isset($_GET['project_id'])) $filters['project_id'] = $_GET['project_id'];
                echo json_encode($api->getTasks($filters));
                break;
                
            case 'employee_tasks':
                if (isset($_GET['employee_id'])) {
                    $status = $_GET['status'] ?? null;
                    echo json_encode($api->getEmployeeTasks($_GET['employee_id'], $status));
                } else {
                    echo json_encode(['error' => 'employee_id required']);
                }
                break;
                
            case 'activity':
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
                echo json_encode($api->getRecentActivity($limit));
                break;
                
            case 'stats':
                echo json_encode($api->getDashboardStats());
                break;
                
            case 'test':
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Enhanced Foxhole API is working!',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'database' => $api->db ? 'connected' : 'disconnected'
                ]);
                break;
                
            default:
                echo json_encode(['error' => 'Invalid action']);
        }
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $api = new DashboardAPI();
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['error' => 'Invalid JSON input']);
            exit;
        }
        
        switch ($input['action'] ?? '') {
            case 'update_status':
                if (isset($input['employee_id']) && isset($input['status'])) {
                    $result = $api->updateEmployeeStatus($input['employee_id'], $input['status']);
                    echo json_encode(['success' => $result]);
                } else {
                    echo json_encode(['error' => 'Missing employee_id or status']);
                }
                break;
                
            case 'update_task_status':
                if (isset($input['task_id']) && isset($input['status'])) {
                    $result = $api->updateTaskStatus($input['task_id'], $input['status']);
                    echo json_encode(['success' => $result]);
                } else {
                    echo json_encode(['error' => 'Missing task_id or status']);
                }
                break;
                
            case 'log_activity':
                if (isset($input['employee_id']) && isset($input['activity'])) {
                    $type = $input['type'] ?? 'general';
                    $result = $api->logActivity($input['employee_id'], $input['activity'], $type);
                    echo json_encode(['success' => $result]);
                } else {
                    echo json_encode(['error' => 'Missing employee_id or activity']);
                }
                break;
                
            default:
                echo json_encode(['error' => 'Invalid action for POST request']);
        }
        
    } else {
        echo json_encode([
            'error' => 'Invalid request method', 
            'allowed_methods' => ['GET', 'POST'],
            'api_info' => 'Enhanced Foxhole Dashboard API v2.0 with Task Management'
        ]);
    }
}
?>