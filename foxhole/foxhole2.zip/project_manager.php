<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foxhole - Project Manager Command Center</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            /* Color System */
            --primary: #4F46E5;
            --primary-light: #6366F1;
            --secondary: #10B981;
            --warning: #F59E0B;
            --danger: #EF4444;
            --success: #10B981;
            --info: #3B82F6;
            
            /* Status Colors */
            --status-active: #16A34A;
            --status-busy: #DC2626;
            --status-away: #EA580C;
            --status-offline: #6B7280;
            
            /* Priority Colors */
            --priority-urgent: #7C2D12;
            --priority-high: #DC2626;
            --priority-medium: #F59E0B;
            --priority-low: #16A34A;
            
            /* Neutrals */
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --gray-900: #0F172A;
            
            --bg-primary: #FAFAFB;
            --bg-secondary: #FFFFFF;
            --bg-tertiary: #F8FAFC;
            
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --radius-xl: 24px;
            
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--gray-900);
            line-height: 1.6;
            font-size: 14px;
        }

        .container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 2rem;
        }

        /* ==================== HEADER ==================== */

        .header {
            background: var(--bg-secondary);
            border-radius: var(--radius-xl);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            border: 2px solid var(--gray-200);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 16px;
            font-size: 32px;
            font-weight: 900;
            color: var(--primary);
        }

        .logo-icon {
            width: 56px;
            height: 56px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 28px;
            box-shadow: var(--shadow-md);
        }

        .header-info h1 {
            font-size: 28px;
            font-weight: 800;
            color: var(--gray-900);
            margin-bottom: 4px;
        }

        .header-info p {
            font-size: 16px;
            color: var(--gray-600);
            font-weight: 500;
        }

        .header-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        /* ==================== BUTTONS ==================== */

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 700;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            font-size: 14px;
            border: 2px solid transparent;
        }

        .btn:focus {
            outline: none;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.3);
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-warning {
            background: var(--warning);
            color: white;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-secondary {
            background: var(--gray-200);
            color: var(--gray-700);
            border-color: var(--gray-300);
        }

        .btn-secondary:hover {
            background: var(--gray-300);
            transform: translateY(-1px);
        }

        .btn-block {
            width: 100%;
            justify-content: center;
        }

        /* ==================== STATS GRID ==================== */

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 2rem;
            box-shadow: var(--shadow-md);
            border: 2px solid var(--gray-200);
            text-align: center;
            transition: var(--transition);
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-xl);
            border-color: var(--primary);
        }

        .stat-number {
            font-size: 48px;
            font-weight: 900;
            color: var(--primary);
            margin-bottom: 8px;
            line-height: 1;
        }

        .stat-label {
            font-size: 16px;
            color: var(--gray-600);
            font-weight: 600;
            margin-bottom: 12px;
        }

        .stat-change {
            font-size: 14px;
            font-weight: 700;
            padding: 6px 12px;
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .stat-change.positive { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .stat-change.negative { background: rgba(239, 68, 68, 0.1); color: var(--danger); }

        /* ==================== TABS ==================== */

        .tabs {
            display: flex;
            border-bottom: 3px solid var(--gray-200);
            margin-bottom: 2rem;
            gap: 4px;
            background: var(--bg-secondary);
            border-radius: var(--radius-lg) var(--radius-lg) 0 0;
            padding: 0 2rem;
            box-shadow: var(--shadow-sm);
        }

        .tab {
            padding: 20px 28px;
            border: none;
            background: none;
            cursor: pointer;
            font-weight: 700;
            color: var(--gray-600);
            border-bottom: 4px solid transparent;
            transition: var(--transition);
            font-size: 16px;
            border-radius: var(--radius-sm) var(--radius-sm) 0 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .tab:hover {
            background: var(--gray-50);
            color: var(--gray-800);
        }

        .tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
            background: var(--bg-primary);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* ==================== MAIN GRID ==================== */

        .main-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .section-card {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 2rem;
            box-shadow: var(--shadow-md);
            border: 2px solid var(--gray-200);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .section-title {
            font-size: 24px;
            font-weight: 800;
            color: var(--gray-900);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* ==================== FORMS ==================== */

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group.full-width {
            grid-column: 1 / -1;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
            color: var(--gray-700);
            font-size: 14px;
        }

        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid var(--gray-200);
            border-radius: var(--radius-md);
            font-size: 14px;
            transition: var(--transition);
            font-family: inherit;
        }

        .form-textarea {
            min-height: 120px;
            resize: vertical;
        }

        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        /* ==================== LISTS ==================== */

        .data-list {
            max-height: 500px;
            overflow-y: auto;
        }

        .list-item {
            display: flex;
            align-items: center;
            padding: 16px;
            border-bottom: 1px solid var(--gray-200);
            transition: var(--transition);
            cursor: pointer;
        }

        .list-item:hover {
            background: var(--gray-50);
            border-radius: var(--radius-sm);
        }

        .list-item:last-child {
            border-bottom: none;
        }

        /* ==================== EMPLOYEE ITEMS ==================== */

        .employee-item {
            display: flex;
            align-items: center;
            padding: 20px;
            border-bottom: 2px solid var(--gray-200);
            transition: var(--transition);
        }

        .employee-item:hover {
            background: var(--gray-50);
            border-radius: var(--radius-md);
        }

        .employee-checkbox {
            margin-right: 16px;
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .employee-avatar {
            width: 56px;
            height: 56px;
            border-radius: var(--radius-lg);
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 800;
            font-size: 20px;
            margin-right: 20px;
            box-shadow: var(--shadow-md);
        }

        .employee-info {
            flex: 1;
        }

        .employee-name {
            font-weight: 800;
            font-size: 18px;
            margin-bottom: 4px;
            color: var(--gray-900);
        }

        .employee-role {
            font-size: 14px;
            color: var(--gray-600);
            margin-bottom: 8px;
        }

        .employee-stats {
            display: flex;
            gap: 16px;
            margin-top: 8px;
        }

        .stat-mini {
            text-align: center;
            padding: 8px 12px;
            background: var(--bg-tertiary);
            border-radius: var(--radius-sm);
            border: 1px solid var(--gray-200);
            min-width: 60px;
        }

        .stat-mini-value {
            font-weight: 800;
            font-size: 16px;
            color: var(--gray-900);
            margin-bottom: 2px;
        }

        .stat-mini-label {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--gray-500);
            font-weight: 600;
        }

        .status-dropdown {
            margin-left: 20px;
        }

        .status-select {
            border: 2px solid var(--gray-300);
            background: var(--bg-secondary);
            border-radius: var(--radius-md);
            padding: 8px 12px;
            font-size: 14px;
            font-weight: 600;
            color: var(--gray-700);
            cursor: pointer;
        }

        /* ==================== STATUS BADGES ==================== */

        .status-badge {
            padding: 6px 12px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-active { background: rgba(22, 163, 74, 0.1); color: var(--status-active); }
        .status-busy { background: rgba(220, 38, 38, 0.1); color: var(--status-busy); }
        .status-away { background: rgba(234, 88, 12, 0.1); color: var(--status-away); }
        .status-offline { background: var(--gray-200); color: var(--status-offline); }

        .priority-urgent { background: rgba(124, 45, 18, 0.1); color: var(--priority-urgent); border-left: 4px solid var(--priority-urgent); }
        .priority-high { background: rgba(220, 38, 38, 0.1); color: var(--priority-high); border-left: 4px solid var(--priority-high); }
        .priority-medium { background: rgba(245, 158, 11, 0.1); color: var(--priority-medium); border-left: 4px solid var(--priority-medium); }
        .priority-low { background: rgba(22, 163, 74, 0.1); color: var(--priority-low); border-left: 4px solid var(--priority-low); }

        /* ==================== TASK ITEMS ==================== */

        .task-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border: 2px solid var(--gray-200);
            border-radius: var(--radius-lg);
            margin-bottom: 16px;
            transition: var(--transition);
        }

        .task-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .task-info {
            flex: 1;
        }

        .task-info h4 {
            margin-bottom: 8px;
            color: var(--gray-900);
            font-weight: 700;
            font-size: 16px;
        }

        .task-meta {
            font-size: 13px;
            color: var(--gray-600);
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
        }

        .task-actions {
            display: flex;
            gap: 8px;
            margin-left: 20px;
        }

        /* ==================== BULK ACTIONS ==================== */

        .bulk-actions {
            background: var(--gray-50);
            padding: 20px;
            border-radius: var(--radius-lg);
            margin-bottom: 2rem;
            border: 2px solid var(--gray-200);
        }

        .bulk-actions-content {
            display: flex;
            gap: 16px;
            align-items: center;
            flex-wrap: wrap;
        }

        .bulk-label {
            font-weight: 700;
            color: var(--gray-700);
            font-size: 16px;
        }

        .bulk-select {
            min-width: 160px;
        }

        /* ==================== MODALS ==================== */

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: var(--bg-secondary);
            margin: 5% auto;
            padding: 2rem;
            border-radius: var(--radius-xl);
            width: 90%;
            max-width: 600px;
            box-shadow: var(--shadow-xl);
            border: 2px solid var(--gray-200);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .modal-title {
            font-size: 28px;
            font-weight: 800;
            color: var(--gray-900);
        }

        .close {
            font-size: 32px;
            cursor: pointer;
            color: var(--gray-400);
            transition: var(--transition);
            border: none;
            background: none;
            padding: 8px;
            border-radius: var(--radius-sm);
        }

        .close:hover {
            color: var(--gray-600);
            background: var(--gray-100);
        }

        /* ==================== MESSAGES ==================== */

        .message {
            margin-bottom: 2rem;
            padding: 20px 24px;
            border-radius: var(--radius-lg);
            font-weight: 600;
            border: 2px solid transparent;
        }

        .message.success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border-color: rgba(16, 185, 129, 0.3);
        }

        .message.error {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border-color: rgba(239, 68, 68, 0.3);
        }

        /* ==================== RESPONSIVE DESIGN ==================== */

        @media (max-width: 1200px) {
            .main-grid {
                grid-template-columns: 1fr;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            .header-content {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .tabs {
                flex-wrap: wrap;
                padding: 0 1rem;
            }
            
            .employee-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 16px;
            }
            
            .employee-stats {
                justify-content: space-between;
                width: 100%;
            }
        }

        /* ==================== LOADING STATES ==================== */

        .loading {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            color: var(--gray-500);
            font-weight: 600;
            padding: 40px;
        }

        .spinner {
            width: 24px;
            height: 24px;
            border: 3px solid var(--gray-300);
            border-top: 3px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="header-left">
                    <div class="logo">
                        <div class="logo-icon">
                            <i class="fas fa-tasks"></i>
                        </div>
                    </div>
                    <div class="header-info">
                        <h1>Project Manager Hub</h1>
                        <p>Team & Project Data Management Center</p>
                    </div>
                </div>
                <div class="header-actions">
                    <a href="dashboard.php" class="btn btn-secondary">
                        <i class="fas fa-chart-pie"></i>
                        CEO Dashboard
                    </a>
                    <button class="btn btn-primary" onclick="refreshData()">
                        <i class="fas fa-sync-alt"></i>
                        Refresh Data
                    </button>
                </div>
            </div>
        </div>

        <!-- Message Display -->
        <div id="message-container"></div>

        <!-- Quick Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number" id="total-employees">0</div>
                <div class="stat-label">Total Team Members</div>
                <div class="stat-change positive">
                    <i class="fas fa-arrow-up"></i>
                    All hands on deck
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="active-employees">0</div>
                <div class="stat-label">Active Today</div>
                <div class="stat-change positive">
                    <i class="fas fa-fire"></i>
                    Ready to work
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="total-projects">0</div>
                <div class="stat-label">Active Projects</div>
                <div class="stat-change positive">
                    <i class="fas fa-rocket"></i>
                    In progress
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-number" id="total-tasks">0</div>
                <div class="stat-label">Total Tasks</div>
                <div class="stat-change positive">
                    <i class="fas fa-check"></i>
                    Getting done
                </div>
            </div>
        </div>

        <!-- Tab Navigation -->
        <div class="tabs">
            <button class="tab active" onclick="showTab('team-management')">
                <i class="fas fa-users"></i> Team Management
            </button>
            <button class="tab" onclick="showTab('project-management')">
                <i class="fas fa-project-diagram"></i> Project Management
            </button>
            <button class="tab" onclick="showTab('task-management')">
                <i class="fas fa-tasks"></i> Task Management
            </button>
            <button class="tab" onclick="showTab('analytics')">
                <i class="fas fa-chart-bar"></i> Analytics
            </button>
        </div>

        <!-- Team Management Tab -->
        <div id="team-management" class="tab-content active">
            <div class="main-grid">
                <!-- Add Employee Form -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-user-plus"></i>
                            Add Team Member
                        </h2>
                    </div>
                    
                    <form id="add-employee-form">
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Full Name *</label>
                                <input type="text" name="name" class="form-input" required 
                                       placeholder="John Doe">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Email *</label>
                                <input type="email" name="email" class="form-input" required 
                                       placeholder="john@neofoxmedia.com">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Role/Position *</label>
                                <input type="text" name="role" class="form-input" required 
                                       placeholder="e.g., Video Editor, Designer">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Employment Type</label>
                                <select name="type" class="form-select" required>
                                    <option value="employee">Full-time Employee</option>
                                    <option value="freelancer">Freelancer/Contractor</option>
                                </select>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-success btn-block">
                            <i class="fas fa-plus"></i>
                            Add Team Member
                        </button>
                    </form>
                </div>

                <!-- Team List & Management -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-users"></i>
                            Team Overview
                        </h2>
                        <button class="btn btn-secondary" onclick="exportTeamData()">
                            <i class="fas fa-download"></i>
                            Export
                        </button>
                    </div>
                    
                    <!-- Bulk Actions -->
                    <div class="bulk-actions">
                        <div class="bulk-actions-content">
                            <span class="bulk-label">Bulk Actions:</span>
                            <select id="bulk-status" class="form-select bulk-select">
                                <option value="active">Set Active</option>
                                <option value="busy">Set Busy</option>
                                <option value="away">Set Away</option>
                                <option value="offline">Set Offline</option>
                            </select>
                            <button class="btn btn-warning" onclick="bulkUpdateStatus()">
                                <i class="fas fa-edit"></i>
                                Update Selected
                            </button>
                            <button class="btn btn-secondary" onclick="selectAllEmployees()">
                                <i class="fas fa-check-square"></i>
                                Select All
                            </button>
                        </div>
                    </div>
                    
                    <div class="data-list" id="employee-list">
                        <div class="loading">
                            <div class="spinner"></div>
                            Loading team data...
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Project Management Tab -->
        <div id="project-management" class="tab-content">
            <div class="main-grid">
                <!-- Add Project Form -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-plus-circle"></i>
                            Create New Project
                        </h2>
                    </div>
                    
                    <form id="add-project-form">
                        <div class="form-group">
                            <label class="form-label">Project Name *</label>
                            <input type="text" name="name" class="form-input" required 
                                   placeholder="e.g., Brand Redesign for ABC Corp">
                        </div>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Client/Company</label>
                                <input type="text" name="client" class="form-input" 
                                       placeholder="Client name or internal project">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Priority Level</label>
                                <select name="priority" class="form-select" required>
                                    <option value="low">Low Priority</option>
                                    <option value="medium" selected>Medium Priority</option>
                                    <option value="high">High Priority</option>
                                    <option value="urgent">Urgent</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Start Date</label>
                                <input type="date" name="start_date" class="form-input">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Target End Date</label>
                                <input type="date" name="end_date" class="form-input">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Project Description</label>
                            <textarea name="description" class="form-textarea" 
                                      placeholder="Brief description of the project scope and objectives..."></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-success btn-block">
                            <i class="fas fa-plus"></i>
                            Create Project
                        </button>
                    </form>
                </div>

                <!-- Projects List -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-project-diagram"></i>
                            Active Projects
                        </h2>
                        <button class="btn btn-secondary" onclick="exportProjectData()">
                            <i class="fas fa-download"></i>
                            Export
                        </button>
                    </div>
                    
                    <div class="data-list" id="project-list">
                        <div class="loading">
                            <div class="spinner"></div>
                            Loading projects...
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Task Management Tab -->
        <div id="task-management" class="tab-content">
            <div class="main-grid">
                <!-- Add Task Form -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-tasks"></i>
                            Assign New Task
                        </h2>
                    </div>
                    
                    <form id="add-task-form">
                        <div class="form-group">
                            <label class="form-label">Task Title *</label>
                            <input type="text" name="title" class="form-input" required 
                                   placeholder="e.g., Create logo concepts">
                        </div>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Assign to Employee</label>
                                <select name="employee_id" class="form-select" id="task-employee-select">
                                    <option value="">Unassigned</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Project</label>
                                <select name="project_id" class="form-select" id="task-project-select">
                                    <option value="">No Project</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Priority</label>
                                <select name="priority" class="form-select">
                                    <option value="low">Low</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="high">High</option>
                                    <option value="urgent">Urgent</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Due Date</label>
                                <input type="date" name="due_date" class="form-input">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Estimated Hours</label>
                            <input type="number" name="estimated_hours" class="form-input" 
                                   step="0.5" min="0" placeholder="e.g., 4.5">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Task Description</label>
                            <textarea name="description" class="form-textarea" 
                                      placeholder="Detailed task description and requirements..."></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-success btn-block">
                            <i class="fas fa-plus"></i>
                            Assign Task
                        </button>
                    </form>
                </div>

                <!-- Tasks Overview -->
                <div class="section-card">
                    <div class="section-header">
                        <h2 class="section-title">
                            <i class="fas fa-list"></i>
                            Recent Tasks
                        </h2>
                        <div>
                            <button class="btn btn-secondary" onclick="filterTasks('all')">All</button>
                            <button class="btn btn-secondary" onclick="filterTasks('urgent')">Urgent</button>
                            <button class="btn btn-secondary" onclick="filterTasks('overdue')">Overdue</button>
                        </div>
                    </div>
                    
                    <div class="data-list" id="task-list">
                        <div class="loading">
                            <div class="spinner"></div>
                            Loading tasks...
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Analytics Tab -->
        <div id="analytics" class="tab-content">
            <div class="section-card">
                <div class="section-header">
                    <h2 class="section-title">
                        <i class="fas fa-chart-bar"></i>
                        Team Analytics & Reports
                    </h2>
                    <button class="btn btn-primary" onclick="generateFullReport()">
                        <i class="fas fa-file-excel"></i>
                        Generate Full Report
                    </button>
                </div>
                
                <div id="analytics-content">
                    <div class="loading">
                        <div class="spinner"></div>
                        Loading analytics...
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // ==================== GLOBAL VARIABLES ====================
        
        let employees = [];
        let projects = [];
        let tasks = [];
        let currentTab = 'team-management';

        // ==================== TAB MANAGEMENT ====================
        
        function showTab(tabId) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(tabId).classList.add('active');
            
            // Add active class to clicked tab
            event.target.closest('.tab').classList.add('active');
            
            currentTab = tabId;
            
            // Load tab-specific data
            loadTabData(tabId);
        }

        function loadTabData(tabId) {
            switch (tabId) {
                case 'team-management':
                    loadEmployees();
                    break;
                case 'project-management':
                    loadProjects();
                    loadEmployeesForDropdown();
                    break;
                case 'task-management':
                    loadTasks();
                    loadEmployeesForDropdown();
                    loadProjectsForDropdown();
                    break;
                case 'analytics':
                    loadAnalytics();
                    break;
            }
        }

        // ==================== DATA LOADING ====================
        
        async function loadEmployees() {
            try {
                const response = await fetch('api_enhanced.php?action=employees');
                employees = await response.json();
                updateEmployeeList();
                updateStats();
            } catch (error) {
                console.error('Error loading employees:', error);
                showMessage('Error loading employee data', 'error');
            }
        }

        async function loadProjects() {
            try {
                const response = await fetch('api_enhanced.php?action=projects');
                projects = await response.json();
                updateProjectList();
                updateStats();
            } catch (error) {
                console.error('Error loading projects:', error);
                showMessage('Error loading project data', 'error');
            }
        }

        async function loadTasks() {
            try {
                const response = await fetch('api_enhanced.php?action=tasks');
                tasks = await response.json();
                updateTaskList();
                updateStats();
            } catch (error) {
                console.error('Error loading tasks:', error);
                showMessage('Error loading task data', 'error');
            }
        }

        async function loadEmployeesForDropdown() {
            if (employees.length === 0) {
                await loadEmployees();
            }
            
            const select = document.getElementById('task-employee-select');
            if (select) {
                select.innerHTML = '<option value="">Unassigned</option>' +
                    employees.map(emp => `<option value="${emp.id}">${emp.name} (${emp.role})</option>`).join('');
            }
        }

        async function loadProjectsForDropdown() {
            if (projects.length === 0) {
                await loadProjects();
            }
            
            const select = document.getElementById('task-project-select');
            if (select) {
                select.innerHTML = '<option value="">No Project</option>' +
                    projects.map(proj => `<option value="${proj.id}">${proj.name}</option>`).join('');
            }
        }

        // ==================== UI UPDATES ====================
        
        function updateStats() {
            document.getElementById('total-employees').textContent = employees.length || 0;
            document.getElementById('active-employees').textContent = employees.filter(emp => emp.status === 'active').length || 0;
            document.getElementById('total-projects').textContent = projects.length || 0;
            document.getElementById('total-tasks').textContent = tasks.length || 0;
        }

        function updateEmployeeList() {
            const container = document.getElementById('employee-list');
            
            if (employees.length === 0) {
                container.innerHTML = '<p style="text-align: center; color: var(--gray-500); padding: 40px;">No employees found. Add your first team member!</p>';
                return;
            }
            
            container.innerHTML = employees.map(emp => `
                <div class="employee-item">
                    <input type="checkbox" class="employee-checkbox" value="${emp.id}">
                    <div class="employee-avatar">
                        ${getInitials(emp.name)}
                    </div>
                    <div class="employee-info">
                        <div class="employee-name">${emp.name}</div>
                        <div class="employee-role">${emp.role} • ${emp.type.charAt(0).toUpperCase() + emp.type.slice(1)}</div>
                        <div class="employee-stats">
                            <div class="stat-mini">
                                <div class="stat-mini-value">${emp.task_count || 0}</div>
                                <div class="stat-mini-label">Tasks</div>
                            </div>
                            <div class="stat-mini">
                                <div class="stat-mini-value">${emp.completed_tasks || 0}</div>
                                <div class="stat-mini-label">Done</div>
                            </div>
                            <div class="stat-mini">
                                <div class="stat-mini-value">${emp.overdue_tasks || 0}</div>
                                <div class="stat-mini-label">Overdue</div>
                            </div>
                            <div class="stat-mini">
                                <div class="stat-mini-value">${Math.round(emp.hours_today || 0)}h</div>
                                <div class="stat-mini-label">Today</div>
                            </div>
                        </div>
                    </div>
                    <div class="status-dropdown">
                        <span class="status-badge status-${emp.status}">${emp.status}</span>
                        <select class="status-select" onchange="updateEmployeeStatus(${emp.id}, this.value)">
                            <option value="active" ${emp.status === 'active' ? 'selected' : ''}>🟢 Active</option>
                            <option value="busy" ${emp.status === 'busy' ? 'selected' : ''}>🔴 Busy</option>
                            <option value="away" ${emp.status === 'away' ? 'selected' : ''}>🟡 Away</option>
                            <option value="offline" ${emp.status === 'offline' ? 'selected' : ''}>⚪ Offline</option>
                        </select>
                    </div>
                </div>
            `).join('');
        }

        function updateProjectList() {
            const container = document.getElementById('project-list');
            
            if (projects.length === 0) {
                container.innerHTML = '<p style="text-align: center; color: var(--gray-500); padding: 40px;">No projects found. Create your first project!</p>';
                return;
            }
            
            container.innerHTML = projects.map(project => `
                <div class="task-item priority-${project.priority}">
                    <div class="task-info">
                        <h4>${project.name}</h4>
                        <div class="task-meta">
                            <span>Client: ${project.client || 'Internal'}</span>
                            <span>Priority: ${project.priority.charAt(0).toUpperCase() + project.priority.slice(1)}</span>
                            <span>Progress: ${project.progress}%</span>
                            <span>Tasks: ${project.total_tasks}</span>
                            <span>Team: ${project.team_size || 0} members</span>
                        </div>
                    </div>
                    <div class="task-actions">
                        <span class="status-badge priority-${project.priority}">${project.priority}</span>
                        <button class="btn btn-secondary" onclick="viewProject(${project.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
            `).join('');
        }

        function updateTaskList() {
            const container = document.getElementById('task-list');
            
            if (tasks.length === 0) {
                container.innerHTML = '<p style="text-align: center; color: var(--gray-500); padding: 40px;">No tasks found. Assign your first task!</p>';
                return;
            }
            
            container.innerHTML = tasks.slice(0, 20).map(task => `
                <div class="task-item priority-${task.priority}">
                    <div class="task-info">
                        <h4>${task.title}</h4>
                        <div class="task-meta">
                            <span>${task.employee_name ? `Assigned to: ${task.employee_name}` : 'Unassigned'}</span>
                            <span>${task.project_name ? `Project: ${task.project_name}` : 'No Project'}</span>
                            <span>Priority: ${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}</span>
                            <span>Status: ${task.status.replace('_', ' ').charAt(0).toUpperCase() + task.status.replace('_', ' ').slice(1)}</span>
                            ${task.due_date ? `<span>Due: ${new Date(task.due_date).toLocaleDateString()}</span>` : ''}
                        </div>
                    </div>
                    <div class="task-actions">
                        <span class="status-badge priority-${task.priority}">${task.priority}</span>
                        <button class="btn btn-secondary" onclick="editTask(${task.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                </div>
            `).join('');
        }

        // ==================== FORM HANDLERS ====================
        
        document.addEventListener('DOMContentLoaded', function() {
            // Add Employee Form
            const addEmployeeForm = document.getElementById('add-employee-form');
            if (addEmployeeForm) {
                addEmployeeForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    const data = {
                        action: 'add_employee',
                        name: formData.get('name'),
                        email: formData.get('email'),
                        role: formData.get('role'),
                        type: formData.get('type')
                    };
                    
                    try {
                        const response = await fetch('api_enhanced.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(data)
                        });
                        
                        const result = await response.json();
                        if (result.success) {
                            showMessage('Employee added successfully!', 'success');
                            this.reset();
                            loadEmployees();
                        } else {
                            showMessage('Error adding employee', 'error');
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        showMessage('Error adding employee', 'error');
                    }
                });
            }

            // Add Project Form
            const addProjectForm = document.getElementById('add-project-form');
            if (addProjectForm) {
                addProjectForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    const data = {
                        action: 'add_project',
                        name: formData.get('name'),
                        description: formData.get('description'),
                        client: formData.get('client'),
                        priority: formData.get('priority'),
                        start_date: formData.get('start_date') || null,
                        end_date: formData.get('end_date') || null
                    };
                    
                    try {
                        const response = await fetch('api_enhanced.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(data)
                        });
                        
                        const result = await response.json();
                        if (result.success) {
                            showMessage('Project created successfully!', 'success');
                            this.reset();
                            loadProjects();
                        } else {
                            showMessage('Error creating project', 'error');
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        showMessage('Error creating project', 'error');
                    }
                });
            }

            // Add Task Form
            const addTaskForm = document.getElementById('add-task-form');
            if (addTaskForm) {
                addTaskForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    
                    const formData = new FormData(this);
                    const data = {
                        action: 'add_task',
                        employee_id: formData.get('employee_id') || null,
                        project_id: formData.get('project_id') || null,
                        title: formData.get('title'),
                        description: formData.get('description'),
                        priority: formData.get('priority'),
                        due_date: formData.get('due_date') || null,
                        estimated_hours: formData.get('estimated_hours') || null
                    };
                    
                    try {
                        const response = await fetch('api_enhanced.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(data)
                        });
                        
                        const result = await response.json();
                        if (result.success) {
                            showMessage('Task assigned successfully!', 'success');
                            this.reset();
                            loadTasks();
                        } else {
                            showMessage('Error assigning task', 'error');
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        showMessage('Error assigning task', 'error');
                    }
                });
            }

            // Initial load
            loadTabData(currentTab);
        });

        // ==================== UTILITY FUNCTIONS ====================
        
        function getInitials(name) {
            return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
        }

        function showMessage(text, type) {
            const container = document.getElementById('message-container');
            container.innerHTML = `<div class="message ${type}">${text}</div>`;
            setTimeout(() => {
                container.innerHTML = '';
            }, 5000);
        }

        async function updateEmployeeStatus(employeeId, status) {
            try {
                const response = await fetch('api_enhanced.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'update_employee_status',
                        employee_id: employeeId,
                        status: status
                    })
                });
                
                const result = await response.json();
                if (result.success) {
                    showMessage('Status updated successfully!', 'success');
                    loadEmployees();
                } else {
                    showMessage('Error updating status', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                showMessage('Error updating status', 'error');
            }
        }

        function bulkUpdateStatus() {
            const selectedEmployees = Array.from(document.querySelectorAll('.employee-checkbox:checked'))
                .map(cb => cb.value);
            
            if (selectedEmployees.length === 0) {
                alert('Please select at least one employee');
                return;
            }
            
            const newStatus = document.getElementById('bulk-status').value;
            
            if (confirm(`Update status to "${newStatus}" for ${selectedEmployees.length} employee(s)?`)) {
                // Implementation for bulk update
                selectedEmployees.forEach(empId => {
                    updateEmployeeStatus(empId, newStatus);
                });
            }
        }

        function selectAllEmployees() {
            const checkboxes = document.querySelectorAll('.employee-checkbox');
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            
            checkboxes.forEach(cb => {
                cb.checked = !allChecked;
            });
        }

        function refreshData() {
            loadTabData(currentTab);
            showMessage('Data refreshed!', 'success');
        }

        function exportTeamData() {
            alert('📊 Exporting team data as CSV...\n\nThis would generate a comprehensive report with:\n• Employee details\n• Current status\n• Task assignments\n• Performance metrics');
        }

        function exportProjectData() {
            alert('📊 Exporting project data as CSV...\n\nThis would include:\n• Project details\n• Progress status\n• Team assignments\n• Timeline information');
        }

        function generateFullReport() {
            alert('📊 Generating comprehensive analytics report...\n\nThis would include:\n• Team productivity metrics\n• Project performance\n• Individual efficiency scores\n• Trend analysis\n• Capacity utilization');
        }

        function filterTasks(filter) {
            console.log('Filtering tasks by:', filter);
            // Implementation for task filtering
        }

        function viewProject(projectId) {
            alert(`📋 Opening project details for ID: ${projectId}\n\nThis would show:\n• Project overview\n• Task breakdown\n• Team assignments\n• Timeline & milestones`);
        }

        function editTask(taskId) {
            alert(`✏️ Editing task ID: ${taskId}\n\nThis would open a modal with:\n• Task details form\n• Status management\n• Time tracking\n• Comments & updates`);
        }

        async function loadAnalytics() {
            const container = document.getElementById('analytics-content');
            
            try {
                const response = await fetch('api_enhanced.php?action=productivity_insights');
                const insights = await response.json();
                
                // Basic analytics display
                container.innerHTML = `
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                        <div class="section-card">
                            <h3>📊 Team Overview</h3>
                            <p>Active Employees: ${insights.team_overview?.active_employees || 0}</p>
                            <p>Total Tasks: ${insights.team_overview?.total_tasks || 0}</p>
                            <p>Completed: ${insights.team_overview?.completed_tasks || 0}</p>
                            <p>Overdue: ${insights.team_overview?.overdue_tasks || 0}</p>
                        </div>
                        
                        <div class="section-card">
                            <h3>🏆 Top Performers</h3>
                            ${(insights.top_performers || []).slice(0, 3).map(performer => `
                                <p><strong>${performer.name}</strong> - ${performer.completed_tasks} tasks (${performer.efficiency_score}% efficiency)</p>
                            `).join('')}
                        </div>
                        
                        <div class="section-card">
                            <h3>📈 Project Health</h3>
                            ${(insights.project_health || []).slice(0, 3).map(project => `
                                <p><strong>${project.name}</strong> - ${project.progress_percentage}% complete</p>
                            `).join('')}
                        </div>
                    </div>
                `;
                
            } catch (error) {
                console.error('Error loading analytics:', error);
                container.innerHTML = '<p>Error loading analytics data.</p>';
            }
        }
    </script>
</body>
</html>