<?php
// api_enhanced.php - BEAST MODE CEO Dashboard API
require_once 'config-2.php';

class DashboardAPI {
    private $db;
    
    public function __construct() {
        try {
            $this->db = new Database();
        } catch (Exception $e) {
            error_log("Database connection failed: " . $e->getMessage());
            $this->db = null;
        }
    }
    
    // ==================== EMPLOYEE MANAGEMENT ====================
    
    public function getEmployees() {
        if (!$this->db) return [];
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                SELECT e.*, 
                       COALESCE(COUNT(DISTINCT t.id), 0) as task_count,
                       COALESCE(COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END), 0) as completed_tasks,
                       COALESCE(COUNT(DISTINCT CASE WHEN t.status = 'in_progress' THEN t.id END), 0) as active_tasks,
                       COALESCE(COUNT(DISTINCT CASE WHEN t.due_date < CURDATE() AND t.status != 'completed' THEN t.id END), 0) as overdue_tasks,
                       COALESCE(SUM(t.hours_logged), 0) as total_hours_logged,
                       COALESCE(SUM(CASE WHEN DATE(t.last_activity) = CURDATE() THEN t.hours_logged ELSE 0 END), 0) as hours_today,
                       COALESCE(AVG(CASE WHEN t.status = 'completed' AND t.estimated_hours > 0 THEN (t.hours_logged / t.estimated_hours) * 100 END), 0) as efficiency_ratio,
                       MAX(COALESCE(t.last_activity, e.last_activity)) as last_activity,
                       COALESCE(COUNT(DISTINCT CASE WHEN t.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY) THEN t.id END), 0) as upcoming_deadlines,
                       CASE 
                           WHEN e.clickup_user_id IS NOT NULL THEN 'ClickUp'
                           WHEN e.notion_user_id IS NOT NULL THEN 'Notion'
                           ELSE 'Manual'
                       END as data_source
                FROM employees e 
                LEFT JOIN tasks t ON e.id = t.employee_id 
                GROUP BY e.id
                ORDER BY 
                    CASE e.status 
                        WHEN 'active' THEN 1 
                        WHEN 'busy' THEN 2 
                        WHEN 'away' THEN 3 
                        ELSE 4 
                    END,
                    e.name
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching employees: " . $e->getMessage());
            return [];
        }
    }
    
    public function getEmployeeDetailedStats($employee_id) {
        if (!$this->db) return [];
        
        try {
            // Get detailed employee performance metrics
            $stmt = $this->db->getConnection()->prepare("
                SELECT 
                    e.*,
                    -- Task Statistics
                    COUNT(DISTINCT t.id) as total_tasks,
                    COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END) as completed_tasks,
                    COUNT(DISTINCT CASE WHEN t.status = 'in_progress' THEN t.id END) as active_tasks,
                    COUNT(DISTINCT CASE WHEN t.status = 'todo' THEN t.id END) as pending_tasks,
                    COUNT(DISTINCT CASE WHEN t.due_date < CURDATE() AND t.status != 'completed' THEN t.id END) as overdue_tasks,
                    
                    -- Time & Productivity
                    COALESCE(SUM(t.hours_logged), 0) as total_hours,
                    COALESCE(SUM(t.estimated_hours), 0) as estimated_hours,
                    COALESCE(AVG(CASE WHEN t.status = 'completed' AND t.estimated_hours > 0 THEN (t.hours_logged / t.estimated_hours) * 100 END), 0) as avg_efficiency,
                    
                    -- Current Week Stats
                    COALESCE(SUM(CASE WHEN WEEK(t.created_at) = WEEK(CURDATE()) THEN t.hours_logged ELSE 0 END), 0) as week_hours,
                    COUNT(DISTINCT CASE WHEN WEEK(t.created_at) = WEEK(CURDATE()) AND t.status = 'completed' THEN t.id END) as week_completed,
                    
                    -- Priority Distribution
                    COUNT(DISTINCT CASE WHEN t.priority = 'urgent' AND t.status != 'completed' THEN t.id END) as urgent_tasks,
                    COUNT(DISTINCT CASE WHEN t.priority = 'high' AND t.status != 'completed' THEN t.id END) as high_priority_tasks,
                    
                    -- Project Involvement
                    COUNT(DISTINCT t.project_id) as projects_involved
                    
                FROM employees e 
                LEFT JOIN tasks t ON e.id = t.employee_id 
                WHERE e.id = ?
                GROUP BY e.id
            ");
            $stmt->execute([$employee_id]);
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Get recent activity for this employee
            $stmt = $this->db->getConnection()->prepare("
                SELECT al.*, 
                       CONCAT(
                           CASE 
                               WHEN TIMESTAMPDIFF(MINUTE, al.created_at, NOW()) < 60 
                               THEN CONCAT(TIMESTAMPDIFF(MINUTE, al.created_at, NOW()), 'm ago')
                               WHEN TIMESTAMPDIFF(HOUR, al.created_at, NOW()) < 24 
                               THEN CONCAT(TIMESTAMPDIFF(HOUR, al.created_at, NOW()), 'h ago')
                               ELSE CONCAT(TIMESTAMPDIFF(DAY, al.created_at, NOW()), 'd ago')
                           END
                       ) as time_formatted
                FROM activity_log al 
                WHERE al.employee_id = ?
                ORDER BY al.created_at DESC 
                LIMIT 10
            ");
            $stmt->execute([$employee_id]);
            $stats['recent_activity'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Get upcoming deadlines for this employee
            $stmt = $this->db->getConnection()->prepare("
                SELECT t.*, p.name as project_name,
                       DATEDIFF(t.due_date, CURDATE()) as days_until_due
                FROM tasks t
                LEFT JOIN projects p ON t.project_id = p.id
                WHERE t.employee_id = ? 
                AND t.status != 'completed' 
                AND t.due_date IS NOT NULL
                ORDER BY t.due_date ASC
                LIMIT 5
            ");
            $stmt->execute([$employee_id]);
            $stats['upcoming_deadlines'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $stats;
        } catch (Exception $e) {
            error_log("Error fetching employee stats: " . $e->getMessage());
            return [];
        }
    }
    
    // ==================== PRODUCTIVITY ANALYTICS ====================
    
    public function getProductivityInsights() {
        if (!$this->db) return [];
        
        try {
            $insights = [];
            
            // Team Efficiency Metrics
            $stmt = $this->db->getConnection()->prepare("
                SELECT 
                    -- Overall Team Stats
                    COUNT(DISTINCT e.id) as total_employees,
                    COUNT(DISTINCT CASE WHEN e.status = 'active' THEN e.id END) as active_employees,
                    COUNT(DISTINCT t.id) as total_tasks,
                    COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END) as completed_tasks,
                    COUNT(DISTINCT CASE WHEN t.due_date < CURDATE() AND t.status != 'completed' THEN t.id END) as overdue_tasks,
                    
                    -- Productivity Rates
                    ROUND(AVG(CASE WHEN t.status = 'completed' AND t.estimated_hours > 0 THEN (t.hours_logged / t.estimated_hours) * 100 END), 1) as avg_efficiency,
                    ROUND(SUM(t.hours_logged) / COUNT(DISTINCT e.id), 1) as avg_hours_per_employee,
                    
                    -- Weekly Trends
                    COUNT(DISTINCT CASE WHEN WEEK(t.created_at) = WEEK(CURDATE()) THEN t.id END) as tasks_this_week,
                    COUNT(DISTINCT CASE WHEN WEEK(t.created_at) = WEEK(CURDATE()) - 1 THEN t.id END) as tasks_last_week,
                    
                    -- Priority Distribution
                    COUNT(DISTINCT CASE WHEN t.priority = 'urgent' AND t.status != 'completed' THEN t.id END) as urgent_pending,
                    COUNT(DISTINCT CASE WHEN t.priority = 'high' AND t.status != 'completed' THEN t.id END) as high_pending
                    
                FROM employees e 
                LEFT JOIN tasks t ON e.id = t.employee_id
            ");
            $stmt->execute();
            $insights['team_overview'] = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Top Performers
            $stmt = $this->db->getConnection()->prepare("
                SELECT e.name, e.role, e.status,
                       COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END) as completed_tasks,
                       COALESCE(SUM(t.hours_logged), 0) as total_hours,
                       ROUND(AVG(CASE WHEN t.status = 'completed' AND t.estimated_hours > 0 THEN (t.hours_logged / t.estimated_hours) * 100 END), 1) as efficiency_score,
                       COUNT(DISTINCT CASE WHEN t.due_date < CURDATE() AND t.status != 'completed' THEN t.id END) as overdue_count
                FROM employees e 
                LEFT JOIN tasks t ON e.id = t.employee_id 
                GROUP BY e.id
                HAVING completed_tasks > 0
                ORDER BY efficiency_score DESC, completed_tasks DESC
                LIMIT 5
            ");
            $stmt->execute();
            $insights['top_performers'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Workload Distribution
            $stmt = $this->db->getConnection()->prepare("
                SELECT e.name, e.role, e.status,
                       COUNT(DISTINCT CASE WHEN t.status != 'completed' THEN t.id END) as active_workload,
                       COUNT(DISTINCT CASE WHEN t.priority = 'urgent' AND t.status != 'completed' THEN t.id END) as urgent_items,
                       COUNT(DISTINCT CASE WHEN t.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY) THEN t.id END) as upcoming_deadlines,
                       CASE 
                           WHEN COUNT(DISTINCT CASE WHEN t.status != 'completed' THEN t.id END) > 10 THEN 'overloaded'
                           WHEN COUNT(DISTINCT CASE WHEN t.status != 'completed' THEN t.id END) > 5 THEN 'busy'
                           WHEN COUNT(DISTINCT CASE WHEN t.status != 'completed' THEN t.id END) > 0 THEN 'normal'
                           ELSE 'available'
                       END as workload_status
                FROM employees e 
                LEFT JOIN tasks t ON e.id = t.employee_id 
                WHERE e.status != 'offline'
                GROUP BY e.id
                ORDER BY active_workload DESC
            ");
            $stmt->execute();
            $insights['workload_distribution'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Project Health Overview
            $stmt = $this->db->getConnection()->prepare("
                SELECT p.name, p.priority, p.status,
                       COUNT(DISTINCT t.id) as total_tasks,
                       COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END) as completed_tasks,
                       COUNT(DISTINCT CASE WHEN t.due_date < CURDATE() AND t.status != 'completed' THEN t.id END) as overdue_tasks,
                       CASE 
                           WHEN COUNT(DISTINCT t.id) > 0 
                           THEN ROUND((COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END) / COUNT(DISTINCT t.id)) * 100, 0)
                           ELSE 0 
                       END as progress_percentage,
                       MIN(CASE WHEN t.status != 'completed' AND t.due_date IS NOT NULL THEN t.due_date END) as next_deadline
                FROM projects p 
                LEFT JOIN tasks t ON p.id = t.project_id 
                WHERE p.status != 'completed'
                GROUP BY p.id
                ORDER BY 
                    CASE p.priority 
                        WHEN 'urgent' THEN 1 
                        WHEN 'high' THEN 2 
                        WHEN 'medium' THEN 3 
                        ELSE 4 
                    END,
                    progress_percentage ASC
            ");
            $stmt->execute();
            $insights['project_health'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $insights;
        } catch (Exception $e) {
            error_log("Error fetching productivity insights: " . $e->getMessage());
            return [];
        }
    }
    
    // ==================== TASK MANAGEMENT ====================
    
    public function getTasks($filters = []) {
        if (!$this->db) return [];
        
        try {
            $whereClause = "WHERE 1=1";
            $params = [];
            
            if (isset($filters['status'])) {
                $whereClause .= " AND t.status = ?";
                $params[] = $filters['status'];
            }
            
            if (isset($filters['employee_id'])) {
                $whereClause .= " AND t.employee_id = ?";
                $params[] = $filters['employee_id'];
            }
            
            if (isset($filters['project_id'])) {
                $whereClause .= " AND t.project_id = ?";
                $params[] = $filters['project_id'];
            }
            
            if (isset($filters['priority'])) {
                $whereClause .= " AND t.priority = ?";
                $params[] = $filters['priority'];
            }
            
            if (isset($filters['overdue']) && $filters['overdue']) {
                $whereClause .= " AND t.due_date < CURDATE() AND t.status != 'completed'";
            }
            
            $stmt = $this->db->getConnection()->prepare("
                SELECT t.*, 
                       e.name as employee_name,
                       p.name as project_name,
                       CASE 
                           WHEN t.due_date < CURDATE() AND t.status != 'completed' THEN 'overdue'
                           WHEN t.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY) THEN 'due_soon'
                           ELSE 'normal'
                       END as urgency_status,
                       DATEDIFF(t.due_date, CURDATE()) as days_until_due,
                       CASE 
                           WHEN t.clickup_task_id IS NOT NULL THEN 'ClickUp'
                           ELSE 'Manual'
                       END as data_source
                FROM tasks t
                LEFT JOIN employees e ON t.employee_id = e.id
                LEFT JOIN projects p ON t.project_id = p.id
                {$whereClause}
                ORDER BY 
                    CASE t.priority 
                        WHEN 'urgent' THEN 1 
                        WHEN 'high' THEN 2 
                        WHEN 'medium' THEN 3 
                        ELSE 4 
                    END,
                    t.due_date ASC,
                    t.created_at DESC
            ");
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching tasks: " . $e->getMessage());
            return [];
        }
    }
    
    public function addTask($employee_id, $project_id, $title, $description = '', $priority = 'medium', $due_date = null, $estimated_hours = null) {
        if (!$this->db) return false;
        
        try {
            // Convert empty strings to null for foreign keys
            $employee_id = $employee_id ?: null;
            $project_id = $project_id ?: null;
            $due_date = $due_date ?: null;
            $estimated_hours = $estimated_hours ?: null;
            
            $stmt = $this->db->getConnection()->prepare("
                INSERT INTO tasks (employee_id, project_id, title, description, status, priority, estimated_hours, due_date, created_at, last_activity) 
                VALUES (?, ?, ?, ?, 'todo', ?, ?, ?, NOW(), NOW())
            ");
            $result = $stmt->execute([$employee_id, $project_id, $title, $description, $priority, $estimated_hours, $due_date]);
            
            if ($result && $employee_id) {
                $this->logActivity($employee_id, "New task assigned: {$title}", 'task_start');
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Error adding task: " . $e->getMessage());
            return false;
        }
    }
    
    public function updateTaskStatus($task_id, $status) {
        if (!$this->db) return false;
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                UPDATE tasks 
                SET status = ?, last_activity = NOW() 
                WHERE id = ?
            ");
            $result = $stmt->execute([$status, $task_id]);
            
            // Log activity if task has an assignee
            if ($result) {
                $stmt = $this->db->getConnection()->prepare("
                    SELECT employee_id, title FROM tasks WHERE id = ?
                ");
                $stmt->execute([$task_id]);
                $task = $stmt->fetch();
                
                if ($task && $task['employee_id']) {
                    $this->logActivity($task['employee_id'], "Task '{$task['title']}' status changed to {$status}", 'task_update');
                }
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Error updating task status: " . $e->getMessage());
            return false;
        }
    }
    
    public function updateTaskHours($task_id, $hours_logged) {
        if (!$this->db) return false;
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                UPDATE tasks 
                SET hours_logged = ?, last_activity = NOW() 
                WHERE id = ?
            ");
            return $stmt->execute([$hours_logged, $task_id]);
        } catch (Exception $e) {
            error_log("Error updating task hours: " . $e->getMessage());
            return false;
        }
    }
    
    // ==================== PROJECT MANAGEMENT ====================
    
    public function getProjects() {
        if (!$this->db) return [];
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                SELECT p.*, 
                       COALESCE(COUNT(DISTINCT t.id), 0) as total_tasks,
                       COALESCE(COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END), 0) as completed_tasks,
                       COALESCE(COUNT(DISTINCT CASE WHEN t.status = 'in_progress' THEN t.id END), 0) as active_tasks,
                       COALESCE(COUNT(DISTINCT CASE WHEN t.due_date < CURDATE() AND t.status != 'completed' THEN t.id END), 0) as overdue_tasks,
                       CASE 
                           WHEN COUNT(DISTINCT t.id) > 0 
                           THEN ROUND((COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END) / COUNT(DISTINCT t.id)) * 100, 0)
                           ELSE 0 
                       END as progress,
                       COALESCE(SUM(t.hours_logged), 0) as total_hours_logged,
                       COALESCE(SUM(t.estimated_hours), 0) as total_estimated_hours,
                       CASE 
                           WHEN p.clickup_project_id IS NOT NULL THEN 'ClickUp'
                           WHEN p.notion_page_id IS NOT NULL THEN 'Notion'
                           ELSE 'Manual'
                       END as data_source,
                       GROUP_CONCAT(DISTINCT e.name ORDER BY e.name SEPARATOR ', ') as team_members,
                       MIN(CASE WHEN t.status != 'completed' AND t.due_date IS NOT NULL THEN t.due_date END) as next_deadline,
                       COUNT(DISTINCT t.employee_id) as team_size
                FROM projects p 
                LEFT JOIN tasks t ON p.id = t.project_id 
                LEFT JOIN employees e ON t.employee_id = e.id
                WHERE p.status != 'completed'
                GROUP BY p.id
                ORDER BY 
                    CASE p.priority 
                        WHEN 'urgent' THEN 1 
                        WHEN 'high' THEN 2 
                        WHEN 'medium' THEN 3 
                        ELSE 4 
                    END,
                    p.name
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching projects: " . $e->getMessage());
            return [];
        }
    }
    
    public function addProject($name, $description, $client, $priority = 'medium', $start_date = null, $end_date = null) {
        if (!$this->db) return false;
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                INSERT INTO projects (name, description, client, priority, status, start_date, end_date, created_at) 
                VALUES (?, ?, ?, ?, 'planning', ?, ?, NOW())
            ");
            return $stmt->execute([$name, $description, $client, $priority, $start_date, $end_date]);
        } catch (Exception $e) {
            error_log("Error adding project: " . $e->getMessage());
            return false;
        }
    }
    
    // ==================== EMPLOYEE MANAGEMENT ====================
    
    public function addEmployee($name, $email, $role, $type = 'employee') {
        if (!$this->db) return false;
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                INSERT INTO employees (name, email, role, type, status, created_at) 
                VALUES (?, ?, ?, ?, 'offline', NOW())
            ");
            $result = $stmt->execute([$name, $email, $role, $type]);
            
            if ($result) {
                $employee_id = $this->db->getConnection()->lastInsertId();
                $this->logActivity($employee_id, "New {$type} added to team", 'general');
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Error adding employee: " . $e->getMessage());
            return false;
        }
    }
    
    public function updateEmployeeStatus($employee_id, $status) {
        if (!$this->db) return false;
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                UPDATE employees 
                SET status = ?, last_activity = NOW() 
                WHERE id = ?
            ");
            $result = $stmt->execute([$status, $employee_id]);
            
            // Log the activity
            if ($result) {
                $this->logActivity($employee_id, "Status changed to {$status}", 'status_change');
            }
            
            return $result;
        } catch (Exception $e) {
            error_log("Error updating employee status: " . $e->getMessage());
            return false;
        }
    }
    
    // ==================== ACTIVITY & REPORTING ====================
    
    public function getRecentActivity($limit = 20) {
        if (!$this->db) return [];
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                SELECT al.*, e.name as employee_name,
                       CONCAT(
                           CASE 
                               WHEN TIMESTAMPDIFF(MINUTE, al.created_at, NOW()) < 60 
                               THEN CONCAT(TIMESTAMPDIFF(MINUTE, al.created_at, NOW()), 'm ago')
                               WHEN TIMESTAMPDIFF(HOUR, al.created_at, NOW()) < 24 
                               THEN CONCAT(TIMESTAMPDIFF(HOUR, al.created_at, NOW()), 'h ago')
                               ELSE CONCAT(TIMESTAMPDIFF(DAY, al.created_at, NOW()), 'd ago')
                           END
                       ) as time_formatted
                FROM activity_log al 
                LEFT JOIN employees e ON al.employee_id = e.id 
                ORDER BY al.created_at DESC 
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error fetching activity: " . $e->getMessage());
            return [];
        }
    }
    
    public function logActivity($employee_id, $activity, $type = 'general') {
        if (!$this->db) return false;
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                INSERT INTO activity_log (employee_id, activity, type, created_at) 
                VALUES (?, ?, ?, NOW())
            ");
            return $stmt->execute([$employee_id, $activity, $type]);
        } catch (Exception $e) {
            error_log("Error logging activity: " . $e->getMessage());
            return false;
        }
    }
    
    public function getDashboardStats() {
        if (!$this->db) {
            return [
                'total_employees' => 0,
                'active_employees' => 0,
                'total_projects' => 0,
                'completed_tasks' => 0,
                'avg_productivity' => 0,
                'overdue_tasks' => 0,
                'urgent_tasks' => 0,
                'total_hours_logged' => 0
            ];
        }
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                SELECT 
                    -- Employee metrics
                    COUNT(DISTINCT e.id) as total_employees,
                    COUNT(DISTINCT CASE WHEN e.status = 'active' THEN e.id END) as active_employees,
                    
                    -- Project metrics
                    COUNT(DISTINCT p.id) as total_projects,
                    
                    -- Task metrics
                    COUNT(DISTINCT t.id) as total_tasks,
                    COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END) as completed_tasks,
                    COUNT(DISTINCT CASE WHEN t.due_date < CURDATE() AND t.status != 'completed' THEN t.id END) as overdue_tasks,
                    COUNT(DISTINCT CASE WHEN t.priority = 'urgent' AND t.status != 'completed' THEN t.id END) as urgent_tasks,
                    
                    -- Time tracking
                    COALESCE(SUM(t.hours_logged), 0) as total_hours_logged,
                    ROUND(AVG(CASE WHEN t.status = 'completed' AND t.estimated_hours > 0 THEN (t.hours_logged / t.estimated_hours) * 100 END), 1) as avg_productivity
                    
                FROM employees e 
                LEFT JOIN tasks t ON e.id = t.employee_id 
                LEFT JOIN projects p ON t.project_id = p.id
                WHERE p.status != 'completed' OR p.id IS NULL
            ");
            $stmt->execute();
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return [
                'total_employees' => $stats['total_employees'] ?: 0,
                'active_employees' => $stats['active_employees'] ?: 0,
                'total_projects' => $stats['total_projects'] ?: 0,
                'completed_tasks' => $stats['completed_tasks'] ?: 0,
                'avg_productivity' => $stats['avg_productivity'] ?: 0,
                'overdue_tasks' => $stats['overdue_tasks'] ?: 0,
                'urgent_tasks' => $stats['urgent_tasks'] ?: 0,
                'total_hours_logged' => $stats['total_hours_logged'] ?: 0
            ];
        } catch (Exception $e) {
            error_log("Error getting dashboard stats: " . $e->getMessage());
            return [
                'total_employees' => 0,
                'active_employees' => 0,
                'total_projects' => 0,
                'completed_tasks' => 0,
                'avg_productivity' => 0,
                'overdue_tasks' => 0,
                'urgent_tasks' => 0,
                'total_hours_logged' => 0
            ];
        }
    }
    
    // ==================== ADVANCED REPORTING ====================
    
    public function getWeeklyReport() {
        if (!$this->db) return [];
        
        try {
            $report = [];
            
            // Weekly team performance
            $stmt = $this->db->getConnection()->prepare("
                SELECT 
                    WEEK(t.created_at) as week_number,
                    YEAR(t.created_at) as year,
                    COUNT(DISTINCT t.id) as tasks_created,
                    COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.id END) as tasks_completed,
                    COALESCE(SUM(t.hours_logged), 0) as hours_logged,
                    COUNT(DISTINCT t.employee_id) as active_employees
                FROM tasks t
                WHERE t.created_at >= DATE_SUB(NOW(), INTERVAL 8 WEEK)
                GROUP BY WEEK(t.created_at), YEAR(t.created_at)
                ORDER BY year DESC, week_number DESC
                LIMIT 8
            ");
            $stmt->execute();
            $report['weekly_trends'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Individual weekly performance
            $stmt = $this->db->getConnection()->prepare("
                SELECT e.name, e.role,
                       COUNT(DISTINCT CASE WHEN WEEK(t.created_at) = WEEK(CURDATE()) THEN t.id END) as week_tasks,
                       COUNT(DISTINCT CASE WHEN WEEK(t.created_at) = WEEK(CURDATE()) AND t.status = 'completed' THEN t.id END) as week_completed,
                       COALESCE(SUM(CASE WHEN WEEK(t.created_at) = WEEK(CURDATE()) THEN t.hours_logged ELSE 0 END), 0) as week_hours
                FROM employees e 
                LEFT JOIN tasks t ON e.id = t.employee_id 
                GROUP BY e.id
                HAVING week_tasks > 0 OR week_completed > 0 OR week_hours > 0
                ORDER BY week_completed DESC, week_hours DESC
            ");
            $stmt->execute();
            $report['individual_weekly'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            return $report;
        } catch (Exception $e) {
            error_log("Error generating weekly report: " . $e->getMessage());
            return [];
        }
    }
    
    public function getCapacityAnalysis() {
        if (!$this->db) return [];
        
        try {
            $stmt = $this->db->getConnection()->prepare("
                SELECT e.name, e.role, e.status, e.type,
                       COUNT(DISTINCT CASE WHEN t.status != 'completed' THEN t.id END) as active_tasks,
                       COUNT(DISTINCT CASE WHEN t.priority = 'urgent' AND t.status != 'completed' THEN t.id END) as urgent_tasks,
                       COUNT(DISTINCT CASE WHEN t.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN t.id END) as due_this_week,
                       COALESCE(SUM(CASE WHEN t.status != 'completed' THEN t.estimated_hours ELSE 0 END), 0) as estimated_remaining_hours,
                       CASE 
                           WHEN COUNT(DISTINCT CASE WHEN t.status != 'completed' THEN t.id END) = 0 THEN 'available'
                           WHEN COUNT(DISTINCT CASE WHEN t.status != 'completed' THEN t.id END) <= 3 THEN 'light'
                           WHEN COUNT(DISTINCT CASE WHEN t.status != 'completed' THEN t.id END) <= 7 THEN 'moderate'
                           WHEN COUNT(DISTINCT CASE WHEN t.status != 'completed' THEN t.id END) <= 12 THEN 'heavy'
                           ELSE 'overloaded'
                       END as capacity_status
                FROM employees e 
                LEFT JOIN tasks t ON e.id = t.employee_id 
                WHERE e.status != 'offline'
                GROUP BY e.id
                ORDER BY active_tasks DESC, urgent_tasks DESC
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Error getting capacity analysis: " . $e->getMessage());
            return [];
        }
    }
}

// ONLY run API endpoint logic if this file is accessed directly (not included)
if (basename($_SERVER['PHP_SELF']) === 'api_enhanced.php') {
    header('Content-Type: application/json');
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action'])) {
        $api = new DashboardAPI();
        
        switch ($_GET['action']) {
            case 'employees':
                echo json_encode($api->getEmployees());
                break;
                
            case 'employee_details':
                if (isset($_GET['employee_id'])) {
                    echo json_encode($api->getEmployeeDetailedStats($_GET['employee_id']));
                } else {
                    echo json_encode(['error' => 'employee_id required']);
                }
                break;
                
            case 'projects':
                echo json_encode($api->getProjects());
                break;
                
            case 'tasks':
                $filters = [];
                if (isset($_GET['status'])) $filters['status'] = $_GET['status'];
                if (isset($_GET['employee_id'])) $filters['employee_id'] = $_GET['employee_id'];
                if (isset($_GET['project_id'])) $filters['project_id'] = $_GET['project_id'];
                if (isset($_GET['priority'])) $filters['priority'] = $_GET['priority'];
                if (isset($_GET['overdue'])) $filters['overdue'] = $_GET['overdue'] === 'true';
                echo json_encode($api->getTasks($filters));
                break;
                
            case 'activity':
                $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
                echo json_encode($api->getRecentActivity($limit));
                break;
                
            case 'stats':
                echo json_encode($api->getDashboardStats());
                break;
                
            case 'productivity_insights':
                echo json_encode($api->getProductivityInsights());
                break;
                
            case 'weekly_report':
                echo json_encode($api->getWeeklyReport());
                break;
                
            case 'capacity_analysis':
                echo json_encode($api->getCapacityAnalysis());
                break;
                
            case 'test':
                echo json_encode([
                    'status' => 'success',
                    'message' => 'BEAST MODE Foxhole API is working!',
                    'timestamp' => date('Y-m-d H:i:s'),
                    'database' => $api->db ? 'connected' : 'disconnected'
                ]);
                break;
                
            default:
                echo json_encode(['error' => 'Invalid action']);
        }
        
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $api = new DashboardAPI();
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['error' => 'Invalid JSON input']);
            exit;
        }
        
        switch ($input['action'] ?? '') {
            case 'update_employee_status':
                if (isset($input['employee_id']) && isset($input['status'])) {
                    $result = $api->updateEmployeeStatus($input['employee_id'], $input['status']);
                    echo json_encode(['success' => $result]);
                } else {
                    echo json_encode(['error' => 'Missing employee_id or status']);
                }
                break;
                
            case 'update_task_status':
                if (isset($input['task_id']) && isset($input['status'])) {
                    $result = $api->updateTaskStatus($input['task_id'], $input['status']);
                    echo json_encode(['success' => $result]);
                } else {
                    echo json_encode(['error' => 'Missing task_id or status']);
                }
                break;
                
            case 'update_task_hours':
                if (isset($input['task_id']) && isset($input['hours'])) {
                    $result = $api->updateTaskHours($input['task_id'], $input['hours']);
                    echo json_encode(['success' => $result]);
                } else {
                    echo json_encode(['error' => 'Missing task_id or hours']);
                }
                break;
                
            case 'log_activity':
                if (isset($input['employee_id']) && isset($input['activity'])) {
                    $type = $input['type'] ?? 'general';
                    $result = $api->logActivity($input['employee_id'], $input['activity'], $type);
                    echo json_encode(['success' => $result]);
                } else {
                    echo json_encode(['error' => 'Missing employee_id or activity']);
                }
                break;
                
            default:
                echo json_encode(['error' => 'Invalid action for POST request']);
        }
        
    } else {
        echo json_encode([
            'error' => 'Invalid request method', 
            'allowed_methods' => ['GET', 'POST'],
            'api_info' => 'BEAST MODE Foxhole Dashboard API v3.0 - Advanced Team Analytics'
        ]);
    }
}
?>