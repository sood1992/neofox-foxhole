<?php
// employee_dashboard.php - Individual Employee Dashboard
require_once 'auth.php';
require_once 'config-2.php';
require_once 'api_enhanced.php';

// Initialize authentication
$auth = new FoxholeAuth();
$auth->requireAuth(['employee']);

// Get current user data
$currentUser = $auth->getCurrentUser();
$employeeId = $currentUser['id'];
$employeeName = $currentUser['name'];

// Initialize API
$api = new DashboardAPI();

// Get employee's detailed stats
$employeeStats = $api->getEmployeeDetailedStats($employeeId);

// Get employee's tasks
$tasks = $api->getTasks(['employee_id' => $employeeId]);

// Separate tasks by status
$currentTasks = array_filter($tasks, function($task) {
    return in_array($task['status'], ['todo', 'in_progress', 'review']);
});

$completedTasks = array_filter($tasks, function($task) {
    return $task['status'] === 'completed';
});

// Get upcoming deadlines
$upcomingDeadlines = array_filter($currentTasks, function($task) {
    return !empty($task['due_date']) && $task['days_until_due'] <= 7 && $task['days_until_due'] >= 0;
});

// Sort tasks by priority and due date
usort($currentTasks, function($a, $b) {
    $priorityOrder = ['urgent' => 0, 'high' => 1, 'medium' => 2, 'low' => 3];
    $aPriority = $priorityOrder[$a['priority']] ?? 3;
    $bPriority = $priorityOrder[$b['priority']] ?? 3;
    
    if ($aPriority !== $bPriority) {
        return $aPriority - $bPriority;
    }
    
    // Sort by due date if same priority
    if (!empty($a['due_date']) && !empty($b['due_date'])) {
        return strtotime($a['due_date']) - strtotime($b['due_date']);
    }
    
    return 0;
});

// Calculate statistics
$totalTasks = count($tasks);
$completedThisMonth = count(array_filter($completedTasks, function($task) {
    return date('Y-m', strtotime($task['completed_at'] ?? $task['last_activity'])) === date('Y-m');
}));

$totalHoursThisMonth = array_sum(array_map(function($task) {
    if (date('Y-m', strtotime($task['last_activity'])) === date('Y-m')) {
        return floatval($task['hours_logged']);
    }
    return 0;
}, $tasks));

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_action'])) {
    header('Content-Type: application/json');
    
    switch ($_POST['ajax_action']) {
        case 'update_task_status':
            $taskId = $_POST['task_id'] ?? 0;
            $status = $_POST['status'] ?? '';
            $result = $api->updateTaskStatus($taskId, $status);
            echo json_encode(['success' => $result]);
            break;
            
        case 'log_time':
            $taskId = $_POST['task_id'] ?? 0;
            $hours = $_POST['hours'] ?? 0;
            $result = $api->updateTaskHours($taskId, $hours);
            echo json_encode(['success' => $result]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foxhole - <?= htmlspecialchars($employeeName) ?>'s Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            /* Light Mode Colors */
            --primary: #4F46E5;
            --primary-light: #6366F1;
            --secondary: #10B981;
            --warning: #F59E0B;
            --danger: #EF4444;
            --success: #10B981;
            --info: #3B82F6;
            
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --gray-900: #0F172A;
            
            --bg-primary: #FAFAFB;
            --bg-secondary: #FFFFFF;
            --bg-tertiary: #F8FAFC;
            
            --text-primary: var(--gray-900);
            --text-secondary: var(--gray-600);
            
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --radius-xl: 24px;
        }

        /* Dark Mode */
        body.dark-mode {
            --bg-primary: #0F172A;
            --bg-secondary: #1E293B;
            --bg-tertiary: #334155;
            --text-primary: #F1F5F9;
            --text-secondary: #94A3B8;
            --gray-200: #475569;
            --gray-300: #64748B;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            transition: all 0.3s ease;
        }

        /* Top Navigation */
        .top-nav {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--gray-200);
            padding: 1rem 2rem;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: var(--shadow-sm);
        }

        .nav-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-left {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 24px;
            font-weight: 800;
            color: var(--primary);
            text-decoration: none;
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }

        .welcome-text {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .nav-btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            background: var(--bg-tertiary);
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-btn:hover {
            background: var(--gray-200);
        }

        /* Main Container */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 1.5rem;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--gray-200);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: white;
        }

        .stat-icon.tasks { background: linear-gradient(135deg, var(--primary), var(--primary-light)); }
        .stat-icon.completed { background: linear-gradient(135deg, var(--success), #34D399); }
        .stat-icon.hours { background: linear-gradient(135deg, var(--warning), #FBBF24); }
        .stat-icon.deadline { background: linear-gradient(135deg, var(--danger), #F87171); }

        .stat-number {
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 4px;
            line-height: 1;
        }

        .stat-label {
            font-size: 14px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        /* Task Sections */
        .section {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--gray-200);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-200);
        }

        .section-title {
            font-size: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Task Cards */
        .task-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .task-card {
            background: var(--bg-tertiary);
            border-radius: var(--radius-md);
            padding: 1.5rem;
            border-left: 4px solid var(--gray-300);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .task-card:hover {
            transform: translateX(4px);
            box-shadow: var(--shadow-md);
        }

        .task-card.priority-urgent { border-left-color: var(--danger); }
        .task-card.priority-high { border-left-color: var(--warning); }
        .task-card.priority-medium { border-left-color: var(--info); }
        .task-card.priority-low { border-left-color: var(--success); }

        .task-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }

        .task-title {
            font-weight: 700;
            font-size: 16px;
            margin-bottom: 4px;
        }

        .task-project {
            font-size: 13px;
            color: var(--text-secondary);
        }

        .task-meta {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
            font-size: 13px;
            color: var(--text-secondary);
        }

        .task-meta-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .priority-badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .priority-urgent { background: rgba(239, 68, 68, 0.1); color: var(--danger); }
        .priority-high { background: rgba(245, 158, 11, 0.1); color: var(--warning); }
        .priority-medium { background: rgba(59, 130, 246, 0.1); color: var(--info); }
        .priority-low { background: rgba(16, 185, 129, 0.1); color: var(--success); }

        .task-actions {
            display: flex;
            gap: 8px;
            margin-top: 1rem;
        }

        .task-btn {
            padding: 8px 16px;
            border: none;
            border-radius: var(--radius-sm);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .task-btn-primary {
            background: var(--primary);
            color: white;
        }

        .task-btn-primary:hover {
            background: var(--primary-light);
        }

        .task-btn-secondary {
            background: var(--gray-200);
            color: var(--text-primary);
        }

        .task-btn-secondary:hover {
            background: var(--gray-300);
        }

        /* Time Tracker */
        .time-tracker {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            border-radius: var(--radius-lg);
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
        }

        .timer-display {
            font-size: 48px;
            font-weight: 800;
            text-align: center;
            margin: 1rem 0;
            font-family: 'Courier New', monospace;
        }

        .timer-controls {
            display: flex;
            justify-content: center;
            gap: 1rem;
        }

        .timer-btn {
            padding: 12px 24px;
            border: 2px solid white;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border-radius: var(--radius-md);
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .timer-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 3rem;
            color: var(--text-secondary);
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        /* Progress Bar */
        .progress-bar {
            width: 100%;
            height: 8px;
            background: var(--gray-200);
            border-radius: 4px;
            overflow: hidden;
            margin-top: 8px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--success), #34D399);
            transition: width 0.3s ease;
        }

        /* Calendar View */
        .calendar-widget {
            background: var(--bg-secondary);
            border-radius: var(--radius-lg);
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--gray-200);
        }

        .deadline-item {
            display: flex;
            align-items: center;
            padding: 12px;
            border-left: 3px solid var(--warning);
            background: var(--bg-tertiary);
            border-radius: var(--radius-sm);
            margin-bottom: 8px;
        }

        .deadline-date {
            font-weight: 700;
            color: var(--warning);
            margin-right: 1rem;
            min-width: 80px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .nav-content {
                flex-direction: column;
                gap: 1rem;
            }
            
            .task-header {
                flex-direction: column;
                gap: 8px;
            }
        }

        /* Dark Mode Toggle */
        .dark-mode-toggle {
            position: relative;
            width: 50px;
            height: 24px;
            background: var(--gray-300);
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .dark-mode-toggle.active {
            background: var(--primary);
        }

        .toggle-slider {
            position: absolute;
            top: 2px;
            left: 2px;
            width: 20px;
            height: 20px;
            background: white;
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .dark-mode-toggle.active .toggle-slider {
            transform: translateX(26px);
        }

        /* Notification Badge */
        .notification-badge {
            position: absolute;
            top: -4px;
            right: -4px;
            background: var(--danger);
            color: white;
            font-size: 10px;
            font-weight: 700;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Top Navigation -->
    <nav class="top-nav">
        <div class="nav-content">
            <div class="nav-left">
                <a href="index.html" class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-paw"></i>
                    </div>
                    <span>Foxhole</span>
                </a>
                <div class="welcome-text">
                    Welcome back, <?= htmlspecialchars($employeeName) ?>! 👋
                </div>
            </div>
            
            <div class="nav-right">
                <button class="nav-btn" onclick="toggleDarkMode()">
                    <i class="fas fa-moon"></i>
                    <div class="dark-mode-toggle" id="darkModeToggle">
                        <div class="toggle-slider"></div>
                    </div>
                </button>
                
                <button class="nav-btn" style="position: relative;" onclick="showNotifications()">
                    <i class="fas fa-bell"></i>
                    <?php if ($employeeStats['overdue_tasks'] > 0): ?>
                    <span class="notification-badge"><?= $employeeStats['overdue_tasks'] ?></span>
                    <?php endif; ?>
                </button>
                
                <button class="nav-btn" onclick="logout()">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </button>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="container">
        <!-- Time Tracker Widget -->
        <div class="time-tracker">
            <h3 style="text-align: center; margin-bottom: 1rem;">
                <i class="fas fa-clock"></i> Today's Time Tracker
            </h3>
            <div class="timer-display" id="timerDisplay">00:00:00</div>
            <div class="timer-controls">
                <button class="timer-btn" onclick="startTimer()">
                    <i class="fas fa-play"></i> Start
                </button>
                <button class="timer-btn" onclick="pauseTimer()">
                    <i class="fas fa-pause"></i> Pause
                </button>
                <button class="timer-btn" onclick="stopTimer()">
                    <i class="fas fa-stop"></i> Stop
                </button>
            </div>
            <select id="currentTaskSelect" style="margin-top: 1rem; width: 100%; padding: 10px; border-radius: 8px; background: rgba(255,255,255,0.2); color: white; border: 1px solid white;">
                <option value="">Select a task to track time...</option>
                <?php foreach ($currentTasks as $task): ?>
                <option value="<?= $task['id'] ?>"><?= htmlspecialchars($task['title']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon tasks">
                        <i class="fas fa-tasks"></i>
                    </div>
                </div>
                <div class="stat-number"><?= count($currentTasks) ?></div>
                <div class="stat-label">Active Tasks</div>
                <?php if ($totalTasks > 0): ?>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?= round((count($completedTasks) / $totalTasks) * 100) ?>%"></div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon completed">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
                <div class="stat-number"><?= $completedThisMonth ?></div>
                <div class="stat-label">Completed This Month</div>
                <?php if ($employeeStats['efficiency_ratio'] > 0): ?>
                <div style="font-size: 12px; color: var(--success); margin-top: 8px;">
                    <i class="fas fa-arrow-up"></i> <?= round($employeeStats['efficiency_ratio']) ?>% efficiency
                </div>
                <?php endif; ?>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon hours">
                        <i class="fas fa-hourglass-half"></i>
                    </div>
                </div>
                <div class="stat-number"><?= round($totalHoursThisMonth) ?></div>
                <div class="stat-label">Hours Logged</div>
                <div style="font-size: 12px; color: var(--text-secondary); margin-top: 8px;">
                    This month
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon deadline">
                        <i class="fas fa-calendar-exclamation"></i>
                    </div>
                </div>
                <div class="stat-number"><?= count($upcomingDeadlines) ?></div>
                <div class="stat-label">Upcoming Deadlines</div>
                <?php if (!empty($upcomingDeadlines)): ?>
                <?php $nextDeadline = reset($upcomingDeadlines); ?>
                <div style="font-size: 12px; color: var(--danger); margin-top: 8px;">
                    Next: <?= $nextDeadline['days_until_due'] == 0 ? 'Today' : ($nextDeadline['days_until_due'] == 1 ? 'Tomorrow' : 'In ' . $nextDeadline['days_until_due'] . ' days') ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Upcoming Deadlines Calendar -->
        <?php if (!empty($upcomingDeadlines)): ?>
        <div class="calendar-widget">
            <div class="section-header">
                <h3 class="section-title">
                    <i class="fas fa-calendar-alt"></i>
                    Upcoming Deadlines
                </h3>
            </div>
            
            <?php foreach ($upcomingDeadlines as $task): ?>
            <div class="deadline-item">
                <div class="deadline-date">
                    <?php 
                    if ($task['days_until_due'] == 0) echo 'Today';
                    elseif ($task['days_until_due'] == 1) echo 'Tomorrow';
                    else echo date('M d', strtotime($task['due_date']));
                    ?>
                </div>
                <div>
                    <strong><?= htmlspecialchars($task['title']) ?></strong>
                    <div style="font-size: 12px; color: var(--text-secondary);">
                        <?= htmlspecialchars($task['project_name'] ?? 'No project') ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Current Tasks -->
        <div class="section">
            <div class="section-header">
                <h3 class="section-title">
                    <i class="fas fa-fire"></i>
                    Current Tasks
                </h3>
                <select class="nav-btn" onchange="filterTasks(this.value)">
                    <option value="all">All Tasks</option>
                    <option value="urgent">Urgent Only</option>
                    <option value="today">Due Today</option>
                    <option value="week">This Week</option>
                </select>
            </div>
            
            <div class="task-list" id="currentTasks">
                <?php if (empty($currentTasks)): ?>
                <div class="empty-state">
                    <i class="fas fa-check-circle"></i>
                    <p>No active tasks! Enjoy your free time! 🎉</p>
                </div>
                <?php else: ?>
                    <?php foreach ($currentTasks as $task): ?>
                    <div class="task-card priority-<?= $task['priority'] ?>" data-task-id="<?= $task['id'] ?>">
                        <div class="task-header">
                            <div>
                                <div class="task-title"><?= htmlspecialchars($task['title']) ?></div>
                                <div class="task-project"><?= htmlspecialchars($task['project_name'] ?? 'No project') ?></div>
                            </div>
                            <span class="priority-badge priority-<?= $task['priority'] ?>"><?= ucfirst($task['priority']) ?></span>
                        </div>
                        
                        <div class="task-meta">
                            <?php if (!empty($task['due_date'])): ?>
                            <div class="task-meta-item">
                                <i class="fas fa-clock"></i>
                                <?php 
                                if ($task['days_until_due'] < 0) echo 'Overdue by ' . abs($task['days_until_due']) . ' days';
                                elseif ($task['days_until_due'] == 0) echo 'Due today';
                                elseif ($task['days_until_due'] == 1) echo 'Due tomorrow';
                                else echo 'Due in ' . $task['days_until_due'] . ' days';
                                ?>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($task['estimated_hours'])): ?>
                            <div class="task-meta-item">
                                <i class="fas fa-hourglass-half"></i>
                                Est: <?= $task['estimated_hours'] ?> hours
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($task['hours_logged'] > 0): ?>
                            <div class="task-meta-item">
                                <i class="fas fa-chart-line"></i>
                                Progress: <?= $task['hours_logged'] ?> hours logged
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($task['status'] === 'in_progress' && $task['estimated_hours'] > 0): ?>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: <?= min(100, round(($task['hours_logged'] / $task['estimated_hours']) * 100)) ?>%"></div>
                        </div>
                        <?php endif; ?>
                        
                        <div class="task-actions">
                            <?php if ($task['status'] === 'todo'): ?>
                            <button class="task-btn task-btn-primary" onclick="updateTaskStatus(<?= $task['id'] ?>, 'in_progress')">
                                <i class="fas fa-play"></i>
                                Start Task
                            </button>
                            <?php elseif ($task['status'] === 'in_progress'): ?>
                            <button class="task-btn task-btn-primary" onclick="updateTaskStatus(<?= $task['id'] ?>, 'review')">
                                <i class="fas fa-check"></i>
                                Mark for Review
                            </button>
                            <?php elseif ($task['status'] === 'review'): ?>
                            <button class="task-btn task-btn-primary" onclick="updateTaskStatus(<?= $task['id'] ?>, 'completed')">
                                <i class="fas fa-check-double"></i>
                                Complete
                            </button>
                            <?php endif; ?>
                            
                            <button class="task-btn task-btn-secondary" onclick="viewDetails(<?= $task['id'] ?>)">
                                <i class="fas fa-info-circle"></i>
                                Details
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Activity -->
        <?php if (!empty($employeeStats['recent_activity'])): ?>
        <div class="section">
            <div class="section-header">
                <h3 class="section-title">
                    <i class="fas fa-history"></i>
                    Recent Activity
                </h3>
            </div>
            
            <div class="task-list">
                <?php foreach ($employeeStats['recent_activity'] as $activity): ?>
                <div style="padding: 12px; border-left: 3px solid var(--gray-300); margin-bottom: 8px;">
                    <div style="font-weight: 600; margin-bottom: 4px;"><?= htmlspecialchars($activity['activity']) ?></div>
                    <div style="font-size: 12px; color: var(--text-secondary);">
                        <i class="fas fa-clock"></i> <?= $activity['time_formatted'] ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script>
        // Timer functionality
        let timerInterval;
        let seconds = 0;
        let isTimerRunning = false;
        let currentTaskId = null;

        function updateTimerDisplay() {
            const hours = Math.floor(seconds / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            const secs = seconds % 60;
            
            document.getElementById('timerDisplay').textContent = 
                `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }

        function startTimer() {
            const taskSelect = document.getElementById('currentTaskSelect');
            currentTaskId = taskSelect.value;
            
            if (!currentTaskId) {
                alert('Please select a task to track time');
                return;
            }
            
            if (!isTimerRunning) {
                isTimerRunning = true;
                timerInterval = setInterval(() => {
                    seconds++;
                    updateTimerDisplay();
                }, 1000);
            }
        }

        function pauseTimer() {
            isTimerRunning = false;
            clearInterval(timerInterval);
        }

        function stopTimer() {
            if (seconds === 0) return;
            
            if (confirm('Stop timer and log hours?')) {
                pauseTimer();
                const hours = seconds / 3600;
                
                if (currentTaskId) {
                    // Log hours to the task
                    fetch('employee_dashboard.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `ajax_action=log_time&task_id=${currentTaskId}&hours=${hours.toFixed(2)}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(`Timer stopped. ${Math.floor(hours)} hours ${Math.floor((hours % 1) * 60)} minutes logged.`);
                            seconds = 0;
                            updateTimerDisplay();
                            location.reload(); // Refresh to show updated hours
                        }
                    });
                } else {
                    alert(`Timer stopped. ${Math.floor(hours)} hours ${Math.floor((hours % 1) * 60)} minutes.`);
                    seconds = 0;
                    updateTimerDisplay();
                }
            }
        }

        // Update task status
        function updateTaskStatus(taskId, status) {
            fetch('employee_dashboard.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `ajax_action=update_task_status&task_id=${taskId}&status=${status}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Error updating task status');
                }
            });
        }

        // Dark mode toggle
        function toggleDarkMode() {
            document.body.classList.toggle('dark-mode');
            document.getElementById('darkModeToggle').classList.toggle('active');
            localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
        }

        // Check for saved dark mode preference
        if (localStorage.getItem('darkMode') === 'true') {
            document.body.classList.add('dark-mode');
            document.getElementById('darkModeToggle').classList.add('active');
        }

        // View task details
        function viewDetails(taskId) {
            alert(`Opening task ${taskId} details...`);
        }

        // Filter tasks
        function filterTasks(filter) {
            console.log('Filtering tasks by:', filter);
            // Implement task filtering
        }

        // Show notifications
        function showNotifications() {
            <?php if ($employeeStats['overdue_tasks'] > 0): ?>
            alert('You have <?= $employeeStats['overdue_tasks'] ?> overdue tasks that need attention!');
            <?php else: ?>
            alert('No new notifications');
            <?php endif; ?>
        }

        // Logout
        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                window.location.href = 'auth.php?action=logout';
            }
        }

        // Auto-save timer state
        window.addEventListener('beforeunload', () => {
            if (isTimerRunning) {
                sessionStorage.setItem('timerSeconds', seconds);
                sessionStorage.setItem('timerRunning', 'true');
                sessionStorage.setItem('timerTaskId', currentTaskId);
            }
        });

        // Restore timer state
        window.addEventListener('load', () => {
            const savedSeconds = sessionStorage.getItem('timerSeconds');
            const wasRunning = sessionStorage.getItem('timerRunning') === 'true';
            const savedTaskId = sessionStorage.getItem('timerTaskId');
            
            if (savedSeconds) {
                seconds = parseInt(savedSeconds);
                updateTimerDisplay();
                if (savedTaskId) {
                    document.getElementById('currentTaskSelect').value = savedTaskId;
                    currentTaskId = savedTaskId;
                }
                if (wasRunning) {
                    startTimer();
                }
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                switch(e.key) {
                    case 's': // Start/pause timer
                        e.preventDefault();
                        isTimerRunning ? pauseTimer() : startTimer();
                        break;
                    case 'd': // Toggle dark mode
                        e.preventDefault();
                        toggleDarkMode();
                        break;
                }
            }
        });
    </script>
</body>
</html>