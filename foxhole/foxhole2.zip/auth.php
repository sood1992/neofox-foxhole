<?php
// auth.php - Enhanced Authentication System for Foxhole
session_start();

class FoxholeAuth {
    private $adminPassword = '838838';
    private $pmPassword = 'ZinX1234!@#$';
    private $sessionTimeout = 3600; // 1 hour
    
    public function __construct() {
        // Check session timeout
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $this->sessionTimeout)) {
            $this->logout();
        }
        $_SESSION['last_activity'] = time();
    }
    
    // Authenticate admin
    public function authenticateAdmin($password) {
        if ($password === $this->adminPassword) {
            $_SESSION['user_role'] = 'admin';
            $_SESSION['user_id'] = 0; // Admin ID
            $_SESSION['user_name'] = 'Administrator';
            $_SESSION['login_time'] = time();
            $_SESSION['authenticated'] = true;
            return true;
        }
        return false;
    }
    
    // Authenticate project manager
    public function authenticatePM($password) {
        if ($password === $this->pmPassword) {
            $_SESSION['user_role'] = 'project_manager';
            $_SESSION['user_id'] = 0; // PM ID
            $_SESSION['user_name'] = 'Project Manager';
            $_SESSION['login_time'] = time();
            $_SESSION['authenticated'] = true;
            return true;
        }
        return false;
    }
    
    // Authenticate employee by name
    public function authenticateEmployee($firstName) {
        require_once 'config-2.php';
        require_once 'api_enhanced.php';
        
        $api = new DashboardAPI();
        $employees = $api->getEmployees();
        
        foreach ($employees as $employee) {
            // Match by first name (case insensitive)
            $empFirstName = explode(' ', $employee['name'])[0];
            if (strcasecmp($empFirstName, $firstName) === 0) {
                $_SESSION['user_role'] = 'employee';
                $_SESSION['user_id'] = $employee['id'];
                $_SESSION['user_name'] = $employee['name'];
                $_SESSION['employee_data'] = $employee;
                $_SESSION['login_time'] = time();
                $_SESSION['authenticated'] = true;
                return true;
            }
        }
        return false;
    }
    
    // Check if user is authenticated
    public function isAuthenticated() {
        return isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true;
    }
    
    // Check user role
    public function hasRole($role) {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
    }
    
    // Require authentication
    public function requireAuth($allowedRoles = []) {
        if (!$this->isAuthenticated()) {
            header('Location: index.html');
            exit();
        }
        
        if (!empty($allowedRoles) && !in_array($_SESSION['user_role'], $allowedRoles)) {
            header('HTTP/1.0 403 Forbidden');
            exit('Access denied');
        }
    }
    
    // Get current user data
    public function getCurrentUser() {
        if ($this->isAuthenticated()) {
            return [
                'id' => $_SESSION['user_id'] ?? null,
                'name' => $_SESSION['user_name'] ?? null,
                'role' => $_SESSION['user_role'] ?? null,
                'login_time' => $_SESSION['login_time'] ?? null,
                'employee_data' => $_SESSION['employee_data'] ?? null
            ];
        }
        return null;
    }
    
    // Logout
    public function logout() {
        session_destroy();
        $_SESSION = array();
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
    }
    
    // Log user activity
    public function logActivity($activity, $type = 'general') {
        if ($this->isAuthenticated() && isset($_SESSION['user_id'])) {
            require_once 'api_enhanced.php';
            $api = new DashboardAPI();
            $api->logActivity($_SESSION['user_id'], $activity, $type);
        }
    }
}

// Handle AJAX authentication requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $auth = new FoxholeAuth();
    
    switch ($_POST['action']) {
        case 'admin_login':
            $password = $_POST['password'] ?? '';
            if ($auth->authenticateAdmin($password)) {
                echo json_encode(['success' => true, 'redirect' => 'dashboard.php']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Invalid password']);
            }
            break;
            
        case 'pm_login':
            $password = $_POST['password'] ?? '';
            if ($auth->authenticatePM($password)) {
                echo json_encode(['success' => true, 'redirect' => 'project_manager.php']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Invalid password']);
            }
            break;
            
        case 'employee_login':
            $name = $_POST['name'] ?? '';
            if ($auth->authenticateEmployee($name)) {
                echo json_encode(['success' => true, 'redirect' => 'employee_dashboard.php']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Employee not found']);
            }
            break;
            
        case 'logout':
            $auth->logout();
            echo json_encode(['success' => true, 'redirect' => 'index.html']);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    exit();
}
?>